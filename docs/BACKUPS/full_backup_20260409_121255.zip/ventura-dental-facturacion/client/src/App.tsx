import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { authService } from './services';
import {
  LoginPage,
  DashboardPage,
  NuevoPagoPage,
  HistorialPagosPage,
  TratamientosPage,
  PacientesPage,
  UsuariosPage,
} from './pages';
import './styles/index.css';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  if (!authService.isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const user = authService.getUser();
  if (!authService.isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }
  if (user?.rol !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/pagos/nuevo"
          element={
            <ProtectedRoute>
              <NuevoPagoPage />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/pagos"
          element={
            <ProtectedRoute>
              <HistorialPagosPage />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/pacientes"
          element={
            <ProtectedRoute>
              <PacientesPage />
            </ProtectedRoute>
          }
        />

        <Route
          path="/tratamientos"
          element={
            <ProtectedRoute>
              <TratamientosPage />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/usuarios"
          element={
            <AdminRoute>
              <UsuariosPage />
            </AdminRoute>
          }
        />
        
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
