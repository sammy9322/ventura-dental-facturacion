import { useState, useEffect, useRef } from 'react';
import type { Paciente } from '../types';

interface Props {
  onSelect: (paciente: Paciente) => void;
  selectedPaciente?: Paciente | null;
}

export default function PacienteSearch({ onSelect, selectedPaciente }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Paciente[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (selectedPaciente) {
      setQuery(selectedPaciente.nombre);
    }
  }, [selectedPaciente]);

  const searchPacientes = async (searchQuery: string) => {
    if (searchQuery.length < 1) {
      setResults([]);
      return;
    }

    try {
      const response = await fetch(`/api/pacientes/buscar?q=${encodeURIComponent(searchQuery)}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });
      const data = await response.json();
      setResults(data);
      setIsOpen(true);
      setSelectedIndex(-1);
    } catch (error) {
      console.error('Error buscando pacientes:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
    
    debounceRef.current = setTimeout(() => {
      searchPacientes(value);
    }, 300);
  };

  const handleSelect = (paciente: Paciente) => {
    setQuery(paciente.nombre);
    setIsOpen(false);
    setResults([]);
    onSelect(paciente);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : prev));
    } else if (e.key === 'Enter' && selectedIndex >= 0) {
      e.preventDefault();
      handleSelect(results[selectedIndex]);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  const handleClear = () => {
    setQuery('');
    setResults([]);
    setIsOpen(false);
    onSelect(null as unknown as Paciente);
    inputRef.current?.focus();
  };

  return (
    <div className="form-group" style={{ position: 'relative' }}>
      <label className="form-label">Buscar Paciente</label>
      <div className="search-input">
        <svg viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
        </svg>
        <input
          ref={inputRef}
          type="text"
          className="form-input"
          placeholder="Buscar por nombre, DNI o teléfono..."
          value={query}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => query.length >= 1 && results.length > 0 && setIsOpen(true)}
        />
        {query && (
          <button
            type="button"
            onClick={handleClear}
            style={{
              position: 'absolute',
              right: '0.75rem',
              top: '50%',
              transform: 'translateY(-50%)',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--text-secondary)',
              fontSize: '1.25rem',
            }}
          >
            ×
          </button>
        )}
      </div>
      
      {isOpen && results.length > 0 && (
        <div className="search-results">
          {results.map((paciente, index) => (
            <div
              key={paciente.id}
              className={`search-result-item ${index === selectedIndex ? 'selected' : ''}`}
              onClick={() => handleSelect(paciente)}
            >
              <div className="search-result-name">{paciente.nombre}</div>
              <div className="search-result-detail">
                DNI: {paciente.dni || 'N/A'} | Tel: {paciente.telefono || 'N/A'}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
