import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { authService } from '../services';

interface Props {
  children: React.ReactNode;
}

export default function Layout({ children }: Props) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState<{ nombre_completo: string; rol: string } | null>(null);

  useEffect(() => {
    const userData = authService.getUser();
    setUser(userData);
  }, []);

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  const navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/pagos/nuevo', label: 'Nuevo Pago', icon: '💰' },
    { path: '/pagos', label: 'Historial de Pagos', icon: '📋' },
    { path: '/tratamientos', label: 'Tratamientos', icon: '🦷' },
    { path: '/pacientes', label: 'Pacientes', icon: '👥' },
  ];

  if (user?.rol === 'admin') {
    navItems.push({ path: '/usuarios', label: 'Usuarios', icon: '⚙️' });
  }

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="sidebar-logo">Ventura Dental</div>
        </div>
        
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div style={{ marginBottom: '0.5rem', fontSize: '0.875rem' }}>
            {user?.nombre_completo}
            <span style={{ 
              marginLeft: '0.5rem', 
              fontSize: '0.75rem',
              padding: '0.125rem 0.375rem',
              background: user?.rol === 'admin' ? '#dbeafe' : '#dcfce7',
              color: user?.rol === 'admin' ? '#1e40af' : '#166534',
              borderRadius: '9999px'
            }}>
              {user?.rol}
            </span>
          </div>
          <button onClick={handleLogout} className="btn btn-outline btn-sm" style={{ width: '100%' }}>
            Cerrar Sesión
          </button>
        </div>
      </aside>

      <main className="main-content">
        {children}
      </main>
    </div>
  );
}
