import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { tratamientoService, pacienteService } from '../services';
import { Layout, Modal, PacienteSearch } from '../components';
import type { Tratamiento, Paciente } from '../types';
import { TIPOS_TRATAMIENTO } from '../types';

export default function TratamientosPage() {
  const [tratamientos, setTratamientos] = useState<Tratamiento[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingTratamiento, setEditingTratamiento] = useState<Tratamiento | null>(null);
  const [selectedPaciente, setSelectedPaciente] = useState<Paciente | null>(null);
  const [filters, setFilters] = useState({
    tipo: '',
    estado: '',
  });

  const form = useForm({
    defaultValues: {
      tipo: '',
      descripcion: '',
      monto_total: 0,
      fecha_inicio: new Date().toISOString().split('T')[0],
      fecha_fin: '',
    },
  });

  useEffect(() => {
    loadTratamientos();
  }, [filters]);

  const loadTratamientos = async () => {
    try {
      const data = await tratamientoService.getAll(filters);
      setTratamientos(data);
    } catch (error) {
      console.error('Error cargando tratamientos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (tratamiento?: Tratamiento) => {
    if (tratamiento) {
      setEditingTratamiento(tratamiento);
      setSelectedPaciente({
        id: tratamiento.paciente_id,
        nombre: tratamiento.paciente_nombre || '',
        dni: tratamiento.paciente_dni ? String(tratamiento.paciente_dni) : null,
        telefono: null,
        email: null,
        direccion: null,
        activo: true,
        created_at: '',
        updated_at: '',
      });
      form.reset({
        tipo: tratamiento.tipo,
        descripcion: tratamiento.descripcion || '',
        monto_total: tratamiento.monto_total,
        fecha_inicio: tratamiento.fecha_inicio.split('T')[0],
        fecha_fin: tratamiento.fecha_fin ? tratamiento.fecha_fin.split('T')[0] : '',
      });
    } else {
      setEditingTratamiento(null);
      setSelectedPaciente(null);
      form.reset({
        tipo: '',
        descripcion: '',
        monto_total: 0,
        fecha_inicio: new Date().toISOString().split('T')[0],
        fecha_fin: '',
      });
    }
    setShowModal(true);
  };

  const handleSubmit = async (data: typeof form.formState.defaultValues) => {
    if (!selectedPaciente) {
      alert('Seleccione un paciente');
      return;
    }

    try {
      if (editingTratamiento) {
        await tratamientoService.update(editingTratamiento.id, {
          tipo: data.tipo,
          descripcion: data.descripcion,
          monto_total: Number(data.monto_total),
          fecha_inicio: data.fecha_inicio,
          fecha_fin: data.fecha_fin || undefined,
        });
      } else {
        await tratamientoService.create({
          paciente_id: selectedPaciente.id,
          tipo: data.tipo,
          descripcion: data.descripcion,
          monto_total: Number(data.monto_total),
          fecha_inicio: data.fecha_inicio,
          fecha_fin: data.fecha_fin || undefined,
        });
      }
      setShowModal(false);
      loadTratamientos();
    } catch (error) {
      console.error('Error guardando tratamiento:', error);
      alert('Error al guardar el tratamiento');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('¿Está seguro de cancelar este tratamiento?')) return;
    
    try {
      await tratamientoService.delete(id);
      loadTratamientos();
    } catch (error) {
      console.error('Error eliminando tratamiento:', error);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-PE', {
      style: 'currency',
      currency: 'PEN',
    }).format(value);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('es-PE');
  };

  const getTipoLabel = (tipo: string) => {
    const found = TIPOS_TRATAMIENTO.find(t => t.value === tipo);
    return found ? found.label : tipo;
  };

  const estadoColors: Record<string, string> = {
    activo: 'badge-success',
    completado: 'badge-info',
    cancelado: 'badge-danger',
  };

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Tratamientos</h1>
        <p className="page-subtitle">Gestión de tratamientos de los pacientes</p>
      </div>

      <div className="filters">
        <div className="filter-group">
          <label>Tipo</label>
          <select
            value={filters.tipo}
            onChange={(e) => setFilters({ ...filters, tipo: e.target.value })}
          >
            <option value="">Todos</option>
            {TIPOS_TRATAMIENTO.map(t => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>
        <div className="filter-group">
          <label>Estado</label>
          <select
            value={filters.estado}
            onChange={(e) => setFilters({ ...filters, estado: e.target.value })}
          >
            <option value="">Todos</option>
            <option value="activo">Activo</option>
            <option value="completado">Completado</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
        <button className="btn btn-primary" onClick={() => handleOpenModal()}>
          + Nuevo Tratamiento
        </button>
      </div>

      {loading ? (
        <div className="loading">
          <div className="spinner"></div>
        </div>
      ) : tratamientos.length === 0 ? (
        <div className="empty-state">
          <h3>No hay tratamientos registrados</h3>
          <p>Agregue su primer tratamiento</p>
        </div>
      ) : (
        <div className="card">
          <table className="table">
            <thead>
              <tr>
                <th>Paciente</th>
                <th>Tipo</th>
                <th>Descripción</th>
                <th>Total</th>
                <th>Pagado</th>
                <th>Pendiente</th>
                <th>Fecha Inicio</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {tratamientos.map((tratamiento) => {
                const saldo = tratamiento.monto_total - tratamiento.monto_pagado;
                return (
                  <tr key={tratamiento.id}>
                    <td>
                      <div>{tratamiento.paciente_nombre}</div>
                      <small style={{ color: 'var(--text-secondary)' }}>
                        DNI: {tratamiento.paciente_dni || 'N/A'}
                      </small>
                    </td>
                    <td>{getTipoLabel(tratamiento.tipo)}</td>
                    <td style={{ maxWidth: '200px' }}>
                      {tratamiento.descripcion || '—'}
                    </td>
                    <td style={{ fontWeight: 600 }}>
                      {formatCurrency(tratamiento.monto_total)}
                    </td>
                    <td style={{ color: 'var(--success)' }}>
                      {formatCurrency(tratamiento.monto_pagado)}
                    </td>
                    <td style={{ color: saldo > 0 ? 'var(--danger)' : 'var(--success)', fontWeight: 600 }}>
                      {formatCurrency(saldo)}
                    </td>
                    <td>{formatDate(tratamiento.fecha_inicio)}</td>
                    <td>
                      <span className={`badge ${estadoColors[tratamiento.estado]}`}>
                        {tratamiento.estado}
                      </span>
                    </td>
                    <td>
                      <div className="table-actions">
                        <button
                          className="btn btn-outline btn-sm"
                          onClick={() => handleOpenModal(tratamiento)}
                        >
                          Editar
                        </button>
                        {tratamiento.estado === 'activo' && (
                          <button
                            className="btn btn-danger btn-sm"
                            onClick={() => handleDelete(tratamiento.id)}
                          >
                            Cancelar
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingTratamiento ? 'Editar Tratamiento' : 'Nuevo Tratamiento'}
        size="lg"
        footer={
          <>
            <button className="btn btn-outline" onClick={() => setShowModal(false)}>
              Cancelar
            </button>
            <button className="btn btn-primary" onClick={form.handleSubmit(handleSubmit)}>
              {editingTratamiento ? 'Guardar Cambios' : 'Crear Tratamiento'}
            </button>
          </>
        }
      >
        <form onSubmit={form.handleSubmit(handleSubmit)}>
          {!editingTratamiento && (
            <div className="form-group">
              <label className="form-label">Paciente *</label>
              <PacienteSearch 
                onSelect={(p) => setSelectedPaciente(p)} 
                selectedPaciente={selectedPaciente}
              />
            </div>
          )}

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Tipo de Tratamiento *</label>
              <select
                className="form-select"
                {...form.register('tipo')}
                required
              >
                <option value="">Seleccionar...</option>
                {TIPOS_TRATAMIENTO.map(t => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Monto Total (S/) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-input"
                {...form.register('monto_total', { valueAsNumber: true })}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Descripción</label>
            <textarea
              className="form-textarea"
              rows={3}
              {...form.register('descripcion')}
              placeholder="Detalles del tratamiento..."
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Fecha de Inicio *</label>
              <input
                type="date"
                className="form-input"
                {...form.register('fecha_inicio')}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Fecha de Fin</label>
              <input
                type="date"
                className="form-input"
                {...form.register('fecha_fin')}
              />
            </div>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
