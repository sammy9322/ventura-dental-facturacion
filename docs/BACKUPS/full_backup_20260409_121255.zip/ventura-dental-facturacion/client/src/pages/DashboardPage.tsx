import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { pagoService, authService } from '../services';
import { Layout } from '../components';

export default function DashboardPage() {
  const [stats, setStats] = useState<{
    total_pagos: string;
    monto_total: string;
    monto_promedio: string;
    por_metodo: { metodo_pago: string; cantidad: string; total: string }[];
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const user = authService.getUser();

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const data = await pagoService.getStats();
      setStats(data);
    } catch (error) {
      console.error('Error cargando estadísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: string | number) => {
    return new Intl.NumberFormat('es-PE', {
      style: 'currency',
      currency: 'PEN',
    }).format(Number(value));
  };

  const metodoLabels: Record<string, string> = {
    efectivo: 'Efectivo',
    tarjeta: 'Tarjeta',
    transferencia: 'Transferencia',
    yape: 'Yape',
    plin: 'Plin',
  };

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Bienvenido, {user?.nombre_completo}</p>
      </div>

      {loading ? (
        <div className="loading">
          <div className="spinner"></div>
        </div>
      ) : (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-label">Total de Pagos</div>
              <div className="stat-value">{stats?.total_pagos || 0}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Monto Total</div>
              <div className="stat-value">{formatCurrency(stats?.monto_total || 0)}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Promedio por Pago</div>
              <div className="stat-value">{formatCurrency(stats?.monto_promedio || 0)}</div>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Acciones Rápidas</h3>
            </div>
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <Link to="/pagos/nuevo" className="btn btn-primary btn-lg">
                💰 Registrar Nuevo Pago
              </Link>
              <Link to="/pagos" className="btn btn-outline btn-lg">
                📋 Ver Historial
              </Link>
              <Link to="/pacientes" className="btn btn-outline btn-lg">
                👥 Gestionar Pacientes
              </Link>
            </div>
          </div>

          {stats?.por_metodo && stats.por_metodo.length > 0 && (
            <div className="card" style={{ marginTop: '1.5rem' }}>
              <div className="card-header">
                <h3 className="card-title">Pagos por Método</h3>
              </div>
              <table className="table">
                <thead>
                  <tr>
                    <th>Método</th>
                    <th>Cantidad</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.por_metodo.map((item) => (
                    <tr key={item.metodo_pago}>
                      <td>{metodoLabels[item.metodo_pago] || item.metodo_pago}</td>
                      <td>{item.cantidad}</td>
                      <td>{formatCurrency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </Layout>
  );
}
