import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { pagoService } from '../services';
import { Layout } from '../components';
import type { Pago, MetodoPago } from '../types';

export default function HistorialPagosPage() {
  const [pagos, setPagos] = useState<Pago[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    fechaDesde: '',
    fechaHasta: '',
    estado: '',
  });
  const [selectedPago, setSelectedPago] = useState<Pago | null>(null);

  useEffect(() => {
    loadPagos();
  }, [filters]);

  const loadPagos = async () => {
    try {
      const data = await pagoService.getAll(filters);
      setPagos(data);
    } catch (error) {
      console.error('Error cargando pagos:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-PE', {
      style: 'currency',
      currency: 'PEN',
    }).format(value);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString('es-PE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const metodoLabels: Record<MetodoPago, string> = {
    efectivo: 'Efectivo',
    tarjeta: 'Tarjeta',
    transferencia: 'Transferencia',
    yape: 'Yape',
    plin: 'Plin',
  };

  const estadoColors: Record<string, string> = {
    completado: 'badge-success',
    pendiente: 'badge-warning',
    anulado: 'badge-danger',
  };

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Historial de Pagos</h1>
        <p className="page-subtitle">Lista de todos los pagos registrados</p>
      </div>

      <div className="filters">
        <div className="filter-group">
          <label>Desde</label>
          <input
            type="date"
            value={filters.fechaDesde}
            onChange={(e) => setFilters({ ...filters, fechaDesde: e.target.value })}
          />
        </div>
        <div className="filter-group">
          <label>Hasta</label>
          <input
            type="date"
            value={filters.fechaHasta}
            onChange={(e) => setFilters({ ...filters, fechaHasta: e.target.value })}
          />
        </div>
        <div className="filter-group">
          <label>Estado</label>
          <select
            value={filters.estado}
            onChange={(e) => setFilters({ ...filters, estado: e.target.value })}
          >
            <option value="">Todos</option>
            <option value="completado">Completados</option>
            <option value="pendiente">Pendientes</option>
            <option value="anulado">Anulados</option>
          </select>
        </div>
        <Link to="/pagos/nuevo" className="btn btn-primary">
          + Nuevo Pago
        </Link>
      </div>

      {loading ? (
        <div className="loading">
          <div className="spinner"></div>
        </div>
      ) : pagos.length === 0 ? (
        <div className="empty-state">
          <h3>No hay pagos registrados</h3>
          <p>Comience registrando un nuevo pago</p>
          <Link to="/pagos/nuevo" className="btn btn-primary" style={{ marginTop: '1rem' }}>
            Registrar Pago
          </Link>
        </div>
      ) : (
        <div className="card">
          <table className="table">
            <thead>
              <tr>
                <th>N°</th>
                <th>Fecha</th>
                <th>Paciente</th>
                <th>Concepto</th>
                <th>Método</th>
                <th>Monto</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {pagos.map((pago) => (
                <tr key={pago.id}>
                  <td>{String(pago.id).padStart(4, '0')}</td>
                  <td>{formatDate(pago.created_at)}</td>
                  <td>
                    <div>{pago.paciente_nombre}</div>
                    <small style={{ color: 'var(--text-secondary)' }}>
                      DNI: {pago.paciente_dni || 'N/A'}
                    </small>
                  </td>
                  <td style={{ maxWidth: '200px' }}>{pago.concepto}</td>
                  <td>{metodoLabels[pago.metodo_pago]}</td>
                  <td style={{ fontWeight: 600 }}>{formatCurrency(pago.monto)}</td>
                  <td>
                    <span className={`badge ${estadoColors[pago.estado]}`}>
                      {pago.estado}
                    </span>
                  </td>
                  <td>
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => setSelectedPago(pago)}
                    >
                      Ver
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selectedPago && (
        <div className="modal-overlay" onClick={() => setSelectedPago(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">Detalle del Pago #{selectedPago.id}</h3>
              <button className="modal-close" onClick={() => setSelectedPago(null)}>
                &times;
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Fecha y Hora</label>
                <p>{formatDate(selectedPago.created_at)}</p>
              </div>
              <div className="form-group">
                <label className="form-label">Paciente</label>
                <p>{selectedPago.paciente_nombre}</p>
                <small style={{ color: 'var(--text-secondary)' }}>
                  DNI: {selectedPago.paciente_dni || 'No registrado'}
                </small>
              </div>
              <div className="form-group">
                <label className="form-label">Concepto</label>
                <p>{selectedPago.concepto}</p>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Monto</label>
                  <p style={{ fontWeight: 600, fontSize: '1.25rem' }}>
                    {formatCurrency(selectedPago.monto)}
                  </p>
                </div>
                <div className="form-group">
                  <label className="form-label">Método de Pago</label>
                  <p>{metodoLabels[selectedPago.metodo_pago]}</p>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Estado</label>
                <span className={`badge ${estadoColors[selectedPago.estado]}`}>
                  {selectedPago.estado}
                </span>
              </div>
              <div className="form-group">
                <label className="form-label">Registrado por</label>
                <p>{selectedPago.usuario_nombre}</p>
              </div>
              {selectedPago.firma_dataurl && (
                <div className="form-group">
                  <label className="form-label">Firma</label>
                  <img
                    src={selectedPago.firma_dataurl}
                    alt="Firma del paciente"
                    style={{ maxWidth: '200px', borderBottom: '1px solid #333' }}
                  />
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setSelectedPago(null)}>
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
