import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { pagoService, pacienteService, tratamientoService } from '../services';
import { Layout, PacienteSearch, SignaturePad, Modal } from '../components';
import type { Paciente, Tratamiento, MetodoPago } from '../types';
import { TIPOS_TRATAMIENTO } from '../types';

const nuevoPagoSchema = z.object({
  monto: z.number().positive('El monto debe ser mayor a 0'),
  metodo_pago: z.enum(['efectivo', 'tarjeta', 'transferencia', 'yape', 'plin']),
  concepto: z.string().min(1, 'El concepto es requerido'),
  tratamiento_id: z.number().optional(),
});

type NuevoPagoForm = z.infer<typeof nuevoPagoSchema>;

export default function NuevoPagoPage() {
  const [paciente, setPaciente] = useState<Paciente | null>(null);
  const [tratamientos, setTratamientos] = useState<Tratamiento[]>([]);
  const [tratamientoSeleccionado, setTratamientoSeleccionado] = useState<Tratamiento | null>(null);
  const [showNewPatient, setShowNewPatient] = useState(false);
  const [showComprobante, setShowComprobante] = useState(false);
  const [comprobanteData, setComprobanteData] = useState<{
    numero: string;
    pago: NuevoPagoForm & { paciente_nombre: string; paciente_dni: string };
    firmaUrl: string;
    tratamiento?: { tipo: string; monto_total: number; monto_pagado: number };
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const newPatientForm = useForm({
    defaultValues: {
      nombre: '',
      dni: '',
      telefono: '',
      email: '',
      direccion: '',
    },
  });

  const pagoForm = useForm<NuevoPagoForm>({
    resolver: zodResolver(nuevoPagoSchema),
    defaultValues: {
      monto: 0,
      metodo_pago: 'efectivo',
      concepto: '',
      tratamiento_id: undefined,
    },
  });

  useEffect(() => {
    if (paciente) {
      loadTratamientosPaciente();
    } else {
      setTratamientos([]);
      setTratamientoSeleccionado(null);
    }
  }, [paciente]);

  const loadTratamientosPaciente = async () => {
    if (!paciente) return;
    try {
      const data = await tratamientoService.getByPacienteId(paciente.id);
      setTratamientos(data.filter(t => t.estado === 'activo'));
    } catch (error) {
      console.error('Error cargando tratamientos:', error);
    }
  };

  const handleSelectPaciente = (p: Paciente) => {
    setPaciente(p);
    setTratamientoSeleccionado(null);
    pagoForm.setValue('tratamiento_id', undefined);
    pagoForm.setValue('concepto', '');
    pagoForm.setValue('monto', 0);
  };

  const handleSelectTratamiento = (tratamiento: Tratamiento | null) => {
    setTratamientoSeleccionado(tratamiento);
    if (tratamiento) {
      pagoForm.setValue('tratamiento_id', tratamiento.id);
      const tipoLabel = TIPOS_TRATAMIENTO.find(t => t.value === tratamiento.tipo)?.label || tratamiento.tipo;
      pagoForm.setValue('concepto', `Pago parcial - ${tipoLabel}`);
      const saldo = tratamiento.monto_total - tratamiento.monto_pagado;
      pagoForm.setValue('monto', Number(saldo.toFixed(2)));
    } else {
      pagoForm.setValue('tratamiento_id', undefined);
    }
  };

  const handleCreatePatient = async (data: typeof newPatientForm.formState.defaultValues) => {
    try {
      const newPatient = await pacienteService.create(data);
      setPaciente(newPatient);
      setShowNewPatient(false);
      newPatientForm.reset();
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: string } } };
      setError(error.response?.data?.error || 'Error al crear paciente');
    }
  };

  const handlePagoSubmit = async (data: NuevoPagoForm) => {
    if (!paciente) {
      setError('Seleccione un paciente');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const result = await pagoService.create({
        paciente_id: paciente.id,
        monto: data.monto,
        metodo_pago: data.metodo_pago,
        concepto: data.concepto,
        tratamiento_id: data.tratamiento_id,
      });

      let tratamientoInfo = undefined;
      if (tratamientoSeleccionado) {
        tratamientoInfo = {
          tipo: tratamientoSeleccionado.tipo,
          monto_total: tratamientoSeleccionado.monto_total,
          monto_pagado: tratamientoSeleccionado.monto_pagado + data.monto,
        };
      }

      setComprobanteData({
        numero: result.comprobante.numero,
        pago: {
          monto: data.monto,
          metodo_pago: data.metodo_pago,
          concepto: data.concepto,
          paciente_nombre: paciente.nombre,
          paciente_dni: paciente.dni || '',
        },
        firmaUrl: '',
        tratamiento: tratamientoInfo,
      });
      setShowComprobante(true);
    } catch (err: unknown) {
      const error = err as { response?: { data?: { error?: string } } };
      setError(error.response?.data?.error || 'Error al registrar el pago');
    } finally {
      setLoading(false);
    }
  };

  const handleFirmaSave = (firmaUrl: string) => {
    if (comprobanteData) {
      setComprobanteData({ ...comprobanteData, firmaUrl });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleNewPago = () => {
    setShowComprobante(false);
    setComprobanteData(null);
    setPaciente(null);
    setTratamientoSeleccionado(null);
    setTratamientos([]);
    pagoForm.reset();
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-PE', {
      style: 'currency',
      currency: 'PEN',
    }).format(value);
  };

  const getTipoLabel = (tipo: string) => {
    const found = TIPOS_TRATAMIENTO.find(t => t.value === tipo);
    return found ? found.label : tipo;
  };

  const metodoLabels: Record<MetodoPago, string> = {
    efectivo: 'Efectivo',
    tarjeta: 'Tarjeta',
    transferencia: 'Transferencia',
    yape: 'Yape',
    plin: 'Plin',
  };

  const isOrtodoncia = tratamientoSeleccionado?.tipo === 'ortodoncia';

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Registrar Nuevo Pago</h1>
        <p className="page-subtitle">Complete los datos para registrar un nuevo pago</p>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Datos del Paciente</h3>
            <button 
              className="btn btn-outline btn-sm"
              onClick={() => setShowNewPatient(true)}
            >
              + Nuevo Paciente
            </button>
          </div>

          <PacienteSearch 
            onSelect={handleSelectPaciente} 
            selectedPaciente={paciente}
          />

          {paciente && (
            <>
              <div className="paciente-info">
                <h4>Datos del Paciente</h4>
                <p><strong>Nombre:</strong> {paciente.nombre}</p>
                <p><strong>DNI:</strong> {paciente.dni || 'No registrado'}</p>
                <p><strong>Teléfono:</strong> {paciente.telefono || 'No registrado'}</p>
                <p><strong>Email:</strong> {paciente.email || 'No registrado'}</p>
                <p><strong>Dirección:</strong> {paciente.direccion || 'No registrada'}</p>
              </div>

              {tratamientos.length > 0 && (
                <div className="form-group" style={{ marginTop: '1rem' }}>
                  <label className="form-label">Tratamiento (opcional)</label>
                  <select
                    className="form-select"
                    value={tratamientoSeleccionado?.id || ''}
                    onChange={(e) => {
                      const t = tratamientos.find(tr => tr.id === Number(e.target.value));
                      handleSelectTratamiento(t || null);
                    }}
                  >
                    <option value="">Sin tratamiento específico</option>
                    {tratamientos.map(t => {
                      const saldo = t.monto_total - t.monto_pagado;
                      return (
                        <option key={t.id} value={t.id}>
                          {getTipoLabel(t.tipo)} - Saldo: {formatCurrency(saldo)}
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}

              {tratamientoSeleccionado && isOrtodoncia && (
                <div className="alert alert-success" style={{ marginTop: '1rem' }}>
                  <h4 style={{ marginBottom: '0.5rem' }}>📋 Ortodoncia - Resumen</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                    <div>
                      <strong>Total:</strong><br />
                      {formatCurrency(tratamientoSeleccionado.monto_total)}
                    </div>
                    <div>
                      <strong>Pagado:</strong><br />
                      {formatCurrency(tratamientoSeleccionado.monto_pagado)}
                    </div>
                    <div>
                      <strong>Pendiente:</strong><br />
                      <span style={{ color: 'var(--danger)', fontWeight: 'bold' }}>
                        {formatCurrency(tratamientoSeleccionado.monto_total - tratamientoSeleccionado.monto_pagado)}
                      </span>
                    </div>
                    <div>
                      <strong>Fecha Inicio:</strong><br />
                      {new Date(tratamientoSeleccionado.fecha_inicio).toLocaleDateString('es-PE')}
                    </div>
                  </div>
                  <p style={{ marginTop: '0.5rem', fontSize: '0.875rem' }}>
                    El pago descuenta del saldo pendiente automáticamente.
                  </p>
                </div>
              )}
            </>
          )}
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Datos del Pago</h3>
          </div>

          <form onSubmit={pagoForm.handleSubmit(handlePagoSubmit)}>
            <div className="form-group">
              <label className="form-label">Monto (S/)</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className={`form-input ${pagoForm.formState.errors.monto ? 'error' : ''}`}
                {...pagoForm.register('monto', { valueAsNumber: true })}
              />
              {pagoForm.formState.errors.monto && (
                <span className="form-error">{pagoForm.formState.errors.monto.message}</span>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">Método de Pago</label>
              <select
                className="form-select"
                {...pagoForm.register('metodo_pago')}
              >
                <option value="efectivo">Efectivo</option>
                <option value="tarjeta">Tarjeta</option>
                <option value="transferencia">Transferencia</option>
                <option value="yape">Yape</option>
                <option value="plin">Plin</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Concepto / Descripción</label>
              <textarea
                className={`form-textarea ${pagoForm.formState.errors.concepto ? 'error' : ''}`}
                rows={3}
                {...pagoForm.register('concepto')}
                placeholder="Ej: Consulta dental, Pago parcial ortodoncia..."
              />
              {pagoForm.formState.errors.concepto && (
                <span className="form-error">{pagoForm.formState.errors.concepto.message}</span>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">Firma del Paciente</label>
              <SignaturePad onSave={handleFirmaSave} />
            </div>

            <button
              type="submit"
              className="btn btn-success btn-lg"
              style={{ width: '100%' }}
              disabled={!paciente || loading}
            >
              {loading ? 'Registrando...' : 'Registrar Pago'}
            </button>
          </form>
        </div>
      </div>

      <Modal
        isOpen={showNewPatient}
        onClose={() => setShowNewPatient(false)}
        title="Nuevo Paciente"
        footer={
          <>
            <button 
              className="btn btn-outline"
              onClick={() => setShowNewPatient(false)}
            >
              Cancelar
            </button>
            <button 
              className="btn btn-primary"
              onClick={newPatientForm.handleSubmit(handleCreatePatient)}
            >
              Crear Paciente
            </button>
          </>
        }
      >
        <form onSubmit={newPatientForm.handleSubmit(handleCreatePatient)}>
          <div className="form-group">
            <label className="form-label">Nombre Completo *</label>
            <input
              type="text"
              className="form-input"
              {...newPatientForm.register('nombre')}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">DNI</label>
            <input
              type="text"
              className="form-input"
              {...newPatientForm.register('dni')}
              maxLength={8}
              pattern="[0-9]{8}"
            />
          </div>
          <div className="form-group">
            <label className="form-label">Teléfono</label>
            <input
              type="tel"
              className="form-input"
              {...newPatientForm.register('telefono')}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className="form-input"
              {...newPatientForm.register('email')}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Dirección</label>
            <textarea
              className="form-textarea"
              rows={2}
              {...newPatientForm.register('direccion')}
            />
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={showComprobante}
        onClose={() => setShowComprobante(false)}
        title="Comprobante de Pago"
        size="lg"
      >
        {comprobanteData && (
          <div className="comprobante">
            <div className="comprobante-header">
              <h2>VENTURA DENTAL</h2>
              <p>RUC: 20XXXXXXXXX</p>
              <p>Dirección: Por definir</p>
            </div>

            <div className="comprobante-section">
              <div className="comprobante-row">
                <span className="comprobante-label">COMPROBANTE N°:</span>
                <span>{String(comprobanteData.numero).padStart(6, '0')}</span>
              </div>
              <div className="comprobante-row">
                <span className="comprobante-label">Fecha:</span>
                <span>{new Date().toLocaleString('es-PE')}</span>
              </div>
            </div>

            <div className="comprobante-divider"></div>

            <div className="comprobante-section">
              <div className="comprobante-row">
                <span className="comprobante-label">PACIENTE:</span>
                <span>{comprobanteData.pago.paciente_nombre}</span>
              </div>
              <div className="comprobante-row">
                <span className="comprobante-label">DNI:</span>
                <span>{comprobanteData.pago.paciente_dni || 'N/A'}</span>
              </div>
            </div>

            {comprobanteData.tratamiento && (
              <>
                <div className="comprobante-divider"></div>
                <div className="comprobante-section">
                  <div className="comprobante-row">
                    <span className="comprobante-label">TRATAMIENTO:</span>
                    <span>{getTipoLabel(comprobanteData.tratamiento.tipo)}</span>
                  </div>
                  <div className="comprobante-row">
                    <span className="comprobante-label">TOTAL:</span>
                    <span>{formatCurrency(comprobanteData.tratamiento.monto_total)}</span>
                  </div>
                  <div className="comprobante-row">
                    <span className="comprobante-label">PAGADO:</span>
                    <span>{formatCurrency(comprobanteData.tratamiento.monto_pagado)}</span>
                  </div>
                  <div className="comprobante-row">
                    <span className="comprobante-label">SALDO:</span>
                    <span>{formatCurrency(comprobanteData.tratamiento.monto_total - comprobanteData.tratamiento.monto_pagado)}</span>
                  </div>
                </div>
              </>
            )}

            <div className="comprobante-divider"></div>

            <div className="comprobante-section">
              <div className="comprobante-row">
                <span className="comprobante-label">CONCEPTO:</span>
                <span>{comprobanteData.pago.concepto}</span>
              </div>
              <div className="comprobante-row">
                <span className="comprobante-label">MÉTODO:</span>
                <span>{metodoLabels[comprobanteData.pago.metodo_pago]}</span>
              </div>
            </div>

            <div className="comprobante-divider"></div>

            <div className="comprobante-total">
              TOTAL: S/ {comprobanteData.pago.monto.toFixed(2)}
            </div>

            {comprobanteData.firmaUrl && (
              <div className="comprobante-firma">
                <img src={comprobanteData.firmaUrl} alt="Firma" />
                <p>Firma del Paciente</p>
              </div>
            )}
          </div>
        )}
        
        <div className="no-print" style={{ marginTop: '1.5rem', display: 'flex', gap: '1rem', justifyContent: 'center' }}>
          <button className="btn btn-primary" onClick={handlePrint}>
            🖨️ Imprimir
          </button>
          <button className="btn btn-outline" onClick={handleNewPago}>
            + Nuevo Pago
          </button>
        </div>
      </Modal>
    </Layout>
  );
}
