import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { pacienteService } from '../services';
import { Layout, Modal } from '../components';
import type { Paciente } from '../types';

export default function PacientesPage() {
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingPaciente, setEditingPaciente] = useState<Paciente | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const form = useForm({
    defaultValues: {
      nombre: '',
      dni: '',
      telefono: '',
      email: '',
      direccion: '',
    },
  });

  useEffect(() => {
    loadPacientes();
  }, []);

  useEffect(() => {
    if (searchQuery.length >= 2) {
      searchPacientes();
    } else if (searchQuery.length === 0) {
      loadPacientes();
    }
  }, [searchQuery]);

  const loadPacientes = async () => {
    try {
      const data = await pacienteService.getAll();
      setPacientes(data);
    } catch (error) {
      console.error('Error cargando pacientes:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchPacientes = async () => {
    try {
      const data = await pacienteService.search(searchQuery);
      setPacientes(data);
    } catch (error) {
      console.error('Error buscando pacientes:', error);
    }
  };

  const handleOpenModal = (paciente?: Paciente) => {
    if (paciente) {
      setEditingPaciente(paciente);
      form.reset({
        nombre: paciente.nombre,
        dni: paciente.dni || '',
        telefono: paciente.telefono || '',
        email: paciente.email || '',
        direccion: paciente.direccion || '',
      });
    } else {
      setEditingPaciente(null);
      form.reset({
        nombre: '',
        dni: '',
        telefono: '',
        email: '',
        direccion: '',
      });
    }
    setShowModal(true);
  };

  const handleSubmit = async (data: typeof form.formState.defaultValues) => {
    try {
      if (editingPaciente) {
        await pacienteService.update(editingPaciente.id, data);
      } else {
        await pacienteService.create(data);
      }
      setShowModal(false);
      loadPacientes();
    } catch (error) {
      console.error('Error guardando paciente:', error);
      alert('Error al guardar el paciente');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('¿Está seguro de desactivar este paciente?')) return;
    
    try {
      await pacienteService.delete(id);
      loadPacientes();
    } catch (error) {
      console.error('Error eliminando paciente:', error);
    }
  };

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Gestión de Pacientes</h1>
        <p className="page-subtitle">Lista de pacientes registrados</p>
      </div>

      <div className="card">
        <div className="card-header">
          <div className="search-input" style={{ maxWidth: '300px' }}>
            <svg viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
            </svg>
            <input
              type="text"
              className="form-input"
              placeholder="Buscar por nombre, DNI..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button className="btn btn-primary" onClick={() => handleOpenModal()}>
            + Nuevo Paciente
          </button>
        </div>

        {loading ? (
          <div className="loading">
            <div className="spinner"></div>
          </div>
        ) : pacientes.length === 0 ? (
          <div className="empty-state">
            <h3>No hay pacientes registrados</h3>
            <p>Agregue su primer paciente</p>
          </div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>DNI</th>
                <th>Teléfono</th>
                <th>Email</th>
                <th>Dirección</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {pacientes.map((paciente) => (
                <tr key={paciente.id}>
                  <td style={{ fontWeight: 500 }}>{paciente.nombre}</td>
                  <td>{paciente.dni || '—'}</td>
                  <td>{paciente.telefono || '—'}</td>
                  <td>{paciente.email || '—'}</td>
                  <td style={{ maxWidth: '200px' }}>{paciente.direccion || '—'}</td>
                  <td>
                    <div className="table-actions">
                      <button
                        className="btn btn-outline btn-sm"
                        onClick={() => handleOpenModal(paciente)}
                      >
                        Editar
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(paciente.id)}
                      >
                        Eliminar
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingPaciente ? 'Editar Paciente' : 'Nuevo Paciente'}
        footer={
          <>
            <button className="btn btn-outline" onClick={() => setShowModal(false)}>
              Cancelar
            </button>
            <button className="btn btn-primary" onClick={form.handleSubmit(handleSubmit)}>
              {editingPaciente ? 'Guardar Cambios' : 'Crear Paciente'}
            </button>
          </>
        }
      >
        <form onSubmit={form.handleSubmit(handleSubmit)}>
          <div className="form-group">
            <label className="form-label">Nombre Completo *</label>
            <input
              type="text"
              className="form-input"
              {...form.register('nombre')}
              required
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">DNI</label>
              <input
                type="text"
                className="form-input"
                {...form.register('dni')}
                maxLength={8}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Teléfono</label>
              <input
                type="tel"
                className="form-input"
                {...form.register('telefono')}
              />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className="form-input"
              {...form.register('email')}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Dirección</label>
            <textarea
              className="form-textarea"
              rows={2}
              {...form.register('direccion')}
            />
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
