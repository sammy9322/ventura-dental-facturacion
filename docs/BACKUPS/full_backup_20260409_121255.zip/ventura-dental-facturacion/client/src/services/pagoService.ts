import api from './api';
import type { Pago, Stats, MetodoPago } from '../types';

export const pagoService = {
  async getAll(filters?: {
    fechaDesde?: string;
    fechaHasta?: string;
    pacienteId?: number;
    estado?: string;
  }): Promise<Pago[]> {
    const params = new URLSearchParams();
    if (filters?.fechaDesde) params.append('fechaDesde', filters.fechaDesde);
    if (filters?.fechaHasta) params.append('fechaHasta', filters.fechaHasta);
    if (filters?.pacienteId) params.append('pacienteId', String(filters.pacienteId));
    if (filters?.estado) params.append('estado', filters.estado);
    
    const response = await api.get<Pago[]>(`/pagos?${params.toString()}`);
    return response.data;
  },

  async getById(id: number): Promise<Pago> {
    const response = await api.get<Pago>(`/pagos/${id}`);
    return response.data;
  },

  async create(data: {
    paciente_id: number;
    monto: number;
    metodo_pago: MetodoPago;
    concepto: string;
    firma_dataurl?: string;
    tratamiento_id?: number;
  }): Promise<Pago & { comprobante: { numero: string }; tratamiento?: { id: number; monto_pagado: number } }> {
    const response = await api.post<Pago & { comprobante: { numero: string }; tratamiento?: { id: number; monto_pagado: number } }>('/pagos', data);
    return response.data;
  },

  async updateFirma(id: number, firma_dataurl: string): Promise<Pago> {
    const response = await api.put<Pago>(`/pagos/${id}/firma`, { firma_dataurl });
    return response.data;
  },

  async annul(id: number): Promise<Pago> {
    const response = await api.put<Pago>(`/pagos/${id}/anular`);
    return response.data;
  },

  async getStats(filters?: { fechaDesde?: string; fechaHasta?: string }): Promise<Stats> {
    const params = new URLSearchParams();
    if (filters?.fechaDesde) params.append('fechaDesde', filters.fechaDesde);
    if (filters?.fechaHasta) params.append('fechaHasta', filters.fechaHasta);
    
    const response = await api.get<Stats>(`/pagos/stats?${params.toString()}`);
    return response.data;
  },
};
