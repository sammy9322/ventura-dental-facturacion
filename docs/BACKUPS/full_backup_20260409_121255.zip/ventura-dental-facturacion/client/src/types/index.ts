export interface Usuario {
  id: number;
  username: string;
  nombre_completo: string;
  rol: 'admin' | 'cajero';
  activo: boolean;
  created_at: string;
}

export interface Paciente {
  id: number;
  nombre: string;
  dni: string | null;
  telefono: string | null;
  email: string | null;
  direccion: string | null;
  activo: boolean;
  created_at: string;
  updated_at: string;
}

export interface Pago {
  id: number;
  paciente_id: number;
  usuario_id: number;
  monto: number;
  metodo_pago: 'efectivo' | 'tarjeta' | 'transferencia' | 'yape' | 'plin';
  concepto: string;
  firma_dataurl: string | null;
  estado: 'pendiente' | 'completado' | 'anulado';
  created_at: string;
  paciente_nombre?: string;
  paciente_dni?: string;
  usuario_nombre?: string;
  tratamiento_id?: number;
}

export interface Tratamiento {
  id: number;
  paciente_id: number;
  tipo: string;
  descripcion: string | null;
  monto_total: number;
  monto_pagado: number;
  fecha_inicio: string;
  fecha_fin: string | null;
  estado: 'activo' | 'completado' | 'cancelado';
  created_at: string;
  updated_at: string;
  paciente_nombre?: string;
  paciente_dni?: string;
}

export interface TratamientoSaldo {
  monto_total: number;
  monto_pagado: number;
  saldo: number;
}

export interface Comprobante {
  id: number;
  pago_id: number;
  numero: string;
  monto: number;
  metodo_pago: string;
  concepto: string;
  pago_fecha: string;
  paciente_nombre: string;
  paciente_dni: string;
  paciente_telefono: string;
  paciente_email: string;
  paciente_direccion: string;
  usuario_nombre: string;
  negocio: {
    nombre: string;
    ruc: string;
    direccion: string;
    telefono: string;
  };
}

export interface LoginResponse {
  token: string;
  user: Usuario;
}

export interface Stats {
  total_pagos: string;
  monto_total: string;
  monto_promedio: string;
  por_metodo: {
    metodo_pago: string;
    cantidad: string;
    total: string;
  }[];
}

export type MetodoPago = 'efectivo' | 'tarjeta' | 'transferencia' | 'yape' | 'plin';

export const METODOS_PAGO: { value: MetodoPago; label: string }[] = [
  { value: 'efectivo', label: 'Efectivo' },
  { value: 'tarjeta', label: 'Tarjeta' },
  { value: 'transferencia', label: 'Transferencia' },
  { value: 'yape', label: 'Yape' },
  { value: 'plin', label: 'Plin' },
];

export const TIPOS_TRATAMIENTO: { value: string; label: string }[] = [
  { value: 'ortodoncia', label: 'Ortodoncia' },
  { value: 'endodoncia', label: 'Endodoncia' },
  { value: 'limpieza', label: 'Limpieza Dental' },
  { value: 'corona', label: 'Corona' },
  { value: 'extraccion', label: 'Extracción' },
  { value: 'blanqueamiento', label: 'Blanqueamiento' },
  { value: 'implante', label: 'Implante' },
  { value: 'ortopedia', label: 'Ortopedia' },
  { value: 'resina', label: 'Resina' },
  { value: 'otro', label: 'Otro' },
];
