import { query, getClient } from '../config/database.js';

export interface Pago {
  id: number;
  paciente_id: number;
  usuario_id: number;
  monto: number;
  metodo_pago: 'efectivo' | 'tarjeta' | 'transferencia' | 'yape' | 'plin';
  concepto: string;
  firma_dataurl: string | null;
  estado: 'pendiente' | 'completado' | 'anulado';
  created_at: Date;
}

export interface PagoWithDetails extends Pago {
  paciente_nombre?: string;
  paciente_dni?: string;
  usuario_nombre?: string;
}

export async function getAll(filters?: {
  fechaDesde?: string;
  fechaHasta?: string;
  pacienteId?: number;
  estado?: string;
}) {
  let sql = `
    SELECT p.*, 
           pa.nombre as paciente_nombre, 
           pa.dni as paciente_dni,
           u.nombre_completo as usuario_nombre
    FROM pagos p
    LEFT JOIN pacientes pa ON p.paciente_id = pa.id
    LEFT JOIN usuarios u ON p.usuario_id = u.id
    WHERE 1=1
  `;
  const params: unknown[] = [];
  let idx = 1;

  if (filters?.fechaDesde) {
    sql += ` AND DATE(p.created_at) >= $${idx++}`;
    params.push(filters.fechaDesde);
  }
  if (filters?.fechaHasta) {
    sql += ` AND DATE(p.created_at) <= $${idx++}`;
    params.push(filters.fechaHasta);
  }
  if (filters?.pacienteId) {
    sql += ` AND p.paciente_id = $${idx++}`;
    params.push(filters.pacienteId);
  }
  if (filters?.estado) {
    sql += ` AND p.estado = $${idx++}`;
    params.push(filters.estado);
  }

  sql += ' ORDER BY p.created_at DESC';

  const result = await query(sql, params);
  return result.rows;
}

export async function findById(id: number) {
  const result = await query(
    `SELECT p.*, 
            pa.nombre as paciente_nombre, 
            pa.dni as paciente_dni,
            pa.telefono as paciente_telefono,
            pa.email as paciente_email,
            pa.direccion as paciente_direccion,
            u.nombre_completo as usuario_nombre
     FROM pagos p
     LEFT JOIN pacientes pa ON p.paciente_id = pa.id
     LEFT JOIN usuarios u ON p.usuario_id = u.id
     WHERE p.id = $1`,
    [id]
  );
  return result.rows[0] as PagoWithDetails | undefined;
}

export async function create(data: {
  paciente_id: number;
  usuario_id: number;
  monto: number;
  metodo_pago: string;
  concepto: string;
  firma_dataurl?: string;
  tratamiento_id?: number;
}) {
  const client = await getClient();
  
  try {
    await client.query('BEGIN');

    const pagoResult = await client.query(
      `INSERT INTO pagos (paciente_id, usuario_id, monto, metodo_pago, concepto, firma_dataurl, estado)
       VALUES ($1, $2, $3, $4, $5, $6, 'completado')
       RETURNING *`,
      [data.paciente_id, data.usuario_id, data.monto, data.metodo_pago, data.concepto, data.firma_dataurl || null]
    );

    const pago = pagoResult.rows[0] as Pago;

    const seqResult = await client.query(
      `INSERT INTO sequence_comprobantes (ultimo_numero, anio)
       VALUES (1, EXTRACT(YEAR FROM CURRENT_DATE))
       ON CONFLICT (id) 
       DO UPDATE SET ultimo_numero = sequence_comprobantes.ultimo_numero + 1, updated_at = CURRENT_TIMESTAMP
       RETURNING ultimo_numero`
    );
    const numeroComprobante = seqResult.rows[0].ultimo_numero;

    const comprobanteResult = await client.query(
      `INSERT INTO comprobantes (pago_id, numero)
       VALUES ($1, $2)
       RETURNING *`,
      [pago.id, numeroComprobante]
    );

    let tratamientoActualizado = null;
    if (data.tratamiento_id) {
      const tratamientoResult = await client.query(
        `UPDATE tratamientos 
         SET monto_pagado = monto_pagado + $1, 
             updated_at = CURRENT_TIMESTAMP,
             estado = CASE 
               WHEN monto_pagado + $1 >= monto_total THEN 'completado' 
               ELSE estado 
             END
         WHERE id = $2 
         RETURNING *`,
        [data.monto, data.tratamiento_id]
      );
      tratamientoActualizado = tratamientoResult.rows[0];

      await client.query(
        `INSERT INTO pago_tratamientos (pago_id, tratamiento_id, monto_asignado)
         VALUES ($1, $2, $3)`,
        [pago.id, data.tratamiento_id, data.monto]
      );
    }

    await client.query('COMMIT');

    return {
      ...pago,
      comprobante: comprobanteResult.rows[0],
      tratamiento: tratamientoActualizado
    };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

export async function updateFirma(id: number, firmaDataUrl: string) {
  const result = await query(
    'UPDATE pagos SET firma_dataurl = $1 WHERE id = $2 RETURNING *',
    [firmaDataUrl, id]
  );
  return result.rows[0];
}

export async function annul(id: number) {
  const result = await query(
    "UPDATE pagos SET estado = 'anulado' WHERE id = $1 RETURNING *",
    [id]
  );
  return result.rows[0];
}

export async function getStats(fechaDesde?: string, fechaHasta?: string) {
  let sql = `
    SELECT 
      COUNT(*) as total_pagos,
      COALESCE(SUM(monto), 0) as monto_total,
      COALESCE(AVG(monto), 0) as monto_promedio
    FROM pagos
    WHERE estado = 'completado'
  `;
  const params: unknown[] = [];
  let idx = 1;

  if (fechaDesde) {
    sql += ` AND DATE(created_at) >= $${idx++}`;
    params.push(fechaDesde);
  }
  if (fechaHasta) {
    sql += ` AND DATE(created_at) <= $${idx++}`;
    params.push(fechaHasta);
  }

  const result = await query(sql, params);
  return result.rows[0];
}

export async function getByMetodoPago(fechaDesde?: string, fechaHasta?: string) {
  let sql = `
    SELECT metodo_pago, COUNT(*) as cantidad, COALESCE(SUM(monto), 0) as total
    FROM pagos
    WHERE estado = 'completado'
  `;
  const params: unknown[] = [];
  let idx = 1;

  if (fechaDesde) {
    sql += ` AND DATE(created_at) >= $${idx++}`;
    params.push(fechaDesde);
  }
  if (fechaHasta) {
    sql += ` AND DATE(created_at) <= $${idx++}`;
    params.push(fechaHasta);
  }

  sql += ' GROUP BY metodo_pago ORDER BY total DESC';

  const result = await query(sql, params);
  return result.rows;
}
