import { Router, Response } from 'express';
import { z } from 'zod';
import * as pagoModel from '../models/pago.js';
import * as comprobanteModel from '../models/comprobante.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';
import { config } from '../config/index.js';

const router = Router();

const createPagoSchema = z.object({
  paciente_id: z.number().int().positive('Seleccione un paciente'),
  monto: z.number().positive('El monto debe ser mayor a 0'),
  metodo_pago: z.enum(['efectivo', 'tarjeta', 'transferencia', 'yape', 'plin']),
  concepto: z.string().min(1, 'El concepto es requerido'),
  firma_dataurl: z.string().optional(),
  tratamiento_id: z.number().int().positive().optional(),
});

const updateFirmaSchema = z.object({
  firma_dataurl: z.string().min(1, 'La firma es requerida'),
});

router.use(authenticateToken);

router.get('/', async (req: AuthRequest, res: Response) => {
  try {
    const filters = {
      fechaDesde: req.query.fechaDesde as string | undefined,
      fechaHasta: req.query.fechaHasta as string | undefined,
      pacienteId: req.query.pacienteId ? parseInt(req.query.pacienteId as string) : undefined,
      estado: req.query.estado as string | undefined,
    };
    
    const pagos = await pagoModel.getAll(filters);
    res.json(pagos);
  } catch (error) {
    console.error('Get pagos error:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

router.get('/stats', async (req: AuthRequest, res: Response) => {
  try {
    const filters = {
      fechaDesde: req.query.fechaDesde as string | undefined,
      fechaHasta: req.query.fechaHasta as string | undefined,
    };
    
    const stats = await pagoModel.getStats(filters.fechaDesde, filters.fechaHasta);
    const porMetodo = await pagoModel.getByMetodoPago(filters.fechaDesde, filters.fechaHasta);
    
    res.json({
      ...stats,
      por_metodo: porMetodo,
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

router.get('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const pago = await pagoModel.findById(id);
    if (!pago) {
      return res.status(404).json({ error: 'Pago no encontrado' });
    }
    res.json(pago);
  } catch (error) {
    console.error('Get pago error:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

router.post('/', async (req: AuthRequest, res: Response) => {
  try {
    const data = createPagoSchema.parse(req.body);
    
    const pago = await pagoModel.create({
      ...data,
      usuario_id: req.user!.id,
    });

    res.status(201).json(pago);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Create pago error:', error);
    res.status(500).json({ error: 'Error al registrar el pago' });
  }
});

router.put('/:id/firma', async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const data = updateFirmaSchema.parse(req.body);
    
    const pago = await pagoModel.updateFirma(id, data.firma_dataurl);
    if (!pago) {
      return res.status(404).json({ error: 'Pago no encontrado' });
    }
    
    res.json(pago);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Update firma error:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

router.put('/:id/anular', async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    
    if (req.user!.rol !== 'admin') {
      return res.status(403).json({ error: 'Solo un administrador puede anular pagos' });
    }
    
    const pago = await pagoModel.annul(id);
    if (!pago) {
      return res.status(404).json({ error: 'Pago no encontrado' });
    }
    
    res.json(pago);
  } catch (error) {
    console.error('Annul pago error:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

export default router;
