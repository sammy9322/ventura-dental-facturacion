import { pool } from '../config/database.js';

export async function initDatabase() {
  const client = await pool.connect();
  
  try {
    console.log('Iniciando inicialización de base de datos...');

    await client.query('BEGIN');

    await client.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        nombre_completo VARCHAR(100) NOT NULL,
        rol VARCHAR(20) NOT NULL CHECK (rol IN ('admin', 'cajero')),
        activo BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ Tabla usuarios creada');

    await client.query(`
      CREATE TABLE IF NOT EXISTS pacientes (
        id SERIAL PRIMARY KEY,
        nombre VARCHAR(150) NOT NULL,
        dni VARCHAR(8) UNIQUE,
        telefono VARCHAR(20),
        email VARCHAR(100),
        direccion TEXT,
        activo BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ Tabla pacientes creada');

    await client.query(`
      CREATE TABLE IF NOT EXISTS pagos (
        id SERIAL PRIMARY KEY,
        paciente_id INTEGER REFERENCES pacientes(id),
        usuario_id INTEGER REFERENCES usuarios(id),
        monto DECIMAL(10, 2) NOT NULL,
        metodo_pago VARCHAR(30) NOT NULL,
        concepto TEXT NOT NULL,
        firma_dataurl TEXT,
        estado VARCHAR(20) DEFAULT 'completado' CHECK (estado IN ('pendiente', 'completado', 'anulado')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ Tabla pagos creada');

    await client.query(`
      CREATE TABLE IF NOT EXISTS comprobantes (
        id SERIAL PRIMARY KEY,
        pago_id INTEGER REFERENCES pagos(id) UNIQUE,
        numero VARCHAR(20) UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ Tabla comprobantes creada');

    await client.query(`
      CREATE TABLE IF NOT EXISTS sequence_comprobantes (
        id SERIAL PRIMARY KEY,
        ultimo_numero INTEGER DEFAULT 0,
        anio INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ Tabla sequence_comprobantes creada');

    await client.query('COMMIT');
    console.log('✓ Base de datos inicializada correctamente');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error al inicializar base de datos:', error);
    throw error;
  } finally {
    client.release();
  }
}
