import { pool } from '../config/database.js';
import bcrypt from 'bcrypt';

export async function seedDatabase() {
  const client = await pool.connect();
  
  try {
    console.log('Verificando datos iniciales...');

    const userExists = await client.query(
      'SELECT id FROM usuarios WHERE username = $1',
      ['admin']
    );

    if (userExists.rows.length === 0) {
      const passwordHash = await bcrypt.hash('admin123', 10);
      
      await client.query(`
        INSERT INTO usuarios (username, password_hash, nombre_completo, rol)
        VALUES ($1, $2, $3, $4)
      `, ['admin', passwordHash, 'Administrador', 'admin']);
      
      console.log('✓ Usuario admin creado (username: admin, password: admin123)');

      const cajahash = await bcrypt.hash('caja123', 10);
      await client.query(`
        INSERT INTO usuarios (username, password_hash, nombre_completo, rol)
        VALUES ($1, $2, $3, $4)
      `, ['caja', cajahash, 'Cajero Principal', 'cajero']);
      
      console.log('✓ Usuario caja creado (username: caja, password: caja123)');
    } else {
      console.log('ℹ Usuarios ya existen, omitiendo...');
    }

    const seqExists = await client.query('SELECT id FROM sequence_comprobantes LIMIT 1');
    if (seqExists.rows.length === 0) {
      await client.query(`
        INSERT INTO sequence_comprobantes (ultimo_numero, anio)
        VALUES (0, EXTRACT(YEAR FROM CURRENT_DATE))
      `);
      console.log('✓ Secuencia de comprobantes inicializada');
    }

    console.log('✓ Seed completado');
  } catch (error) {
    console.error('Error en seed:', error);
    throw error;
  } finally {
    client.release();
  }
}
