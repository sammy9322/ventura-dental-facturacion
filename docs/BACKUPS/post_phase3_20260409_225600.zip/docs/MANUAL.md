# Manual del Desarrollador
## Sistema de Facturación - Ventura Dental

**Versión:** 1.0.0  
**Última actualización:** 2026-04-09  
**Stack:** React + Vite (Frontend), Node.js + Express (Backend), PostgreSQL (BD)

---

## Tabla de Contenidos
1. [Arquitectura del Sistema](#arquitectura-del-sistema)
2. [Estructura de Carpetas](#estructura-de-carpetas)
3. [Base de Datos](#base-de-datos)
4. [API Endpoints](#api-endpoints)
5. [Fórmulas y Lógica de Negocio](#fórmulas-y-lógica-de-negocio)
6. [Modelos de Datos](#modelos-de-datos)
7. [Flujos de Usuario](#flujos-de-usuario)
8. [Configuración](#configuración)
9. [Deploy](#deploy)

---

## Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENTE (Browser)                        │
│                    React + Vite + TypeScript                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │  Login   │  │Dashboard │  │  Pagos   │  │Tratamientos│       │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘        │
└─────────────────────────────────────────────────────────────────┘
                                  │
                                  │ HTTP/REST (JSON)
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                         SERVIDOR (Node.js)                       │
│                   Express + TypeScript                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                    API Routes                              │  │
│  │  /auth  /pacientes  /pagos  /tratamientos  /comprobantes │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              │                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                  Database Layer                           │  │
│  │              pg (PostgreSQL Driver)                       │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                                  │
                                  │ SQL
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PostgreSQL Database                           │
│              ventura_dental (Tables & Data)                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Estructura de Carpetas

```
ventura-dental-facturacion/
│
├── server/                          # Backend (Node.js + Express)
│   ├── src/
│   │   ├── config/
│   │   │   ├── database.ts          # Conexión a PostgreSQL
│   │   │   └── index.ts             # Configuración general
│   │   ├── controllers/             # Controladores (lógica de negocio)
│   │   ├── middleware/
│   │   │   ├── auth.ts              # Autenticación JWT
│   │   │   └── errorHandler.ts      # Manejo de errores
│   │   ├── models/
│   │   │   ├── usuario.ts           # Modelo de usuarios
│   │   │   ├── paciente.ts          # Modelo de pacientes
│   │   │   ├── pago.ts              # Modelo de pagos
│   │   │   ├── tratamiento.ts        # Modelo de tratamientos
│   │   │   └── comprobante.ts       # Modelo de comprobantes
│   │   ├── routes/
│   │   │   ├── auth.ts              # Rutas de autenticación
│   │   │   ├── pacientes.ts         # Rutas de pacientes
│   │   │   ├── pagos.ts             # Rutas de pagos
│   │   │   ├── tratamientos.ts       # Rutas de tratamientos
│   │   │   └── comprobantes.ts      # Rutas de comprobantes
│   │   ├── scripts/
│   │   │   ├── initDb.ts            # Script de inicialización BD
│   │   │   └── seedDb.ts            # Script de datos iniciales
│   │   └── index.ts                # Entry point del servidor
│   ├── package.json
│   ├── tsconfig.json
│   └── .env                        # Variables de entorno
│
├── client/                          # Frontend (React + Vite)
│   ├── src/
│   │   ├── components/
│   │   │   ├── Layout.tsx           # Layout principal con sidebar
│   │   │   ├── Modal.tsx            # Componente modal reutilizable
│   │   │   ├── PacienteSearch.tsx    # Buscador de pacientes
│   │   │   └── SignaturePad.tsx      # Canvas para firma digital
│   │   ├── pages/
│   │   │   ├── LoginPage.tsx        # Página de login
│   │   │   ├── DashboardPage.tsx     # Dashboard principal
│   │   │   ├── NuevoPagoPage.tsx    # Registrar nuevo pago
│   │   │   ├── HistorialPagosPage.tsx # Lista de pagos
│   │   │   ├── TratamientosPage.tsx  # Gestión de tratamientos
│   │   │   ├── PacientesPage.tsx     # Gestión de pacientes
│   │   │   └── UsuariosPage.tsx      # Gestión de usuarios (admin)
│   │   ├── services/
│   │   │   ├── api.ts               # Instancia Axios con interceptores
│   │   │   ├── authService.ts       # Servicios de autenticación
│   │   │   ├── pacienteService.ts    # Servicios de pacientes
│   │   │   ├── pagoService.ts        # Servicios de pagos
│   │   │   ├── tratamientoService.ts # Servicios de tratamientos
│   │   │   └── comprobanteService.ts # Servicios de comprobantes
│   │   ├── hooks/
│   │   │   └── useAuth.ts           # Hook personalizado de autenticación
│   │   ├── types/
│   │   │   └── index.ts             # Definiciones de tipos TypeScript
│   │   ├── styles/
│   │   │   └── index.css            # Estilos globales
│   │   ├── App.tsx                  # Componente principal
│   │   └── main.tsx                 # Entry point
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts               # Configuración de Vite
│
├── docs/                            # Documentación
│   ├── BACKUPS/
│   │   └── backup.sh                # Script de respaldo
│   ├── MANUAL.md                    # Este archivo
│   ├── API.md                       # Documentación de API
│   └── ARQUITECTURA.md              # Diagrama de arquitectura
│
└── README.md                        # Guía de inicio rápido
```

---

## Base de Datos

### Diagrama de Entidades

```
┌─────────────────┐       ┌─────────────────┐
│    usuarios     │       │    pacientes    │
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ username         │       │ nombre          │
│ password_hash    │       │ dni             │
│ nombre_completo  │       │ telefono        │
│ rol              │       │ email           │
│ activo           │       │ direccion       │
│ created_at       │       │ activo          │
└────────┬────────┘       └────────┬────────┘
         │                         │
         │                         │
         │    ┌────────────────────┘
         │    │   1:N
         │    ▼
┌─────────────────┐       ┌─────────────────┐
│     pagos       │       │  tratamientos   │
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ paciente_id (FK)│◄──────│ paciente_id (FK)│
│ usuario_id (FK) │       │ tipo            │
│ monto           │       │ descripcion     │
│ metodo_pago     │       │ monto_total     │
│ concepto         │       │ monto_pagado    │
│ firma_dataurl   │       │ fecha_inicio    │
│ estado          │       │ fecha_fin       │
│ created_at      │       │ estado          │
└────────┬────────┘       └─────────────────┘
         │
         │ 1:1
         ▼
┌─────────────────┐       ┌─────────────────┐
│  comprobantes   │       │pago_tratamientos│
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ pago_id (FK)    │       │ pago_id (FK)    │
│ numero          │       │ tratamiento_id  │
│ created_at      │       │ monto_asignado  │
└─────────────────┘       └─────────────────┘
```

### Tabla: usuarios

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| username | VARCHAR(50) | Nombre de usuario para login |
| password_hash | VARCHAR(255) | Contraseña encriptada con bcrypt |
| nombre_completo | VARCHAR(100) | Nombre del usuario |
| rol | VARCHAR(20) | 'admin' o 'cajero' |
| activo | BOOLEAN | Si el usuario está activo |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de última modificación |

### Tabla: pacientes

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| nombre | VARCHAR(150) | Nombre completo del paciente |
| dni | VARCHAR(8) | Número de DNI (único) |
| telefono | VARCHAR(20) | Teléfono de contacto |
| email | VARCHAR(100) | Correo electrónico |
| direccion | TEXT | Dirección del paciente |
| activo | BOOLEAN | Si el paciente está activo |
| created_at | TIMESTAMP | Fecha de registro |
| updated_at | TIMESTAMP | Fecha de última modificación |

### Tabla: tratamientos

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| paciente_id | INTEGER | FK a pacientes |
| tipo | VARCHAR(50) | ortodoncia, endodoncia, limpieza, etc. |
| descripcion | TEXT | Detalles del tratamiento |
| monto_total | DECIMAL(10,2) | Costo total del tratamiento |
| monto_pagado | DECIMAL(10,2) | Monto acumulado de pagos |
| fecha_inicio | DATE | Fecha de inicio |
| fecha_fin | DATE | Fecha de finalización (nullable) |
| estado | VARCHAR(20) | activo, completado, cancelado |
| created_at | TIMESTAMP | Fecha de creación |
| updated_at | TIMESTAMP | Fecha de última modificación |

### Tabla: pagos

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| paciente_id | INTEGER | FK a pacientes |
| usuario_id | INTEGER | FK a usuarios (cajero que registró) |
| monto | DECIMAL(10,2) | Monto del pago |
| metodo_pago | VARCHAR(30) | efectivo, tarjeta, transferencia, yape, plin |
| concepto | TEXT | Descripción del pago |
| firma_dataurl | TEXT | Imagen de firma en Base64 |
| estado | VARCHAR(20) | pendiente, completado, anulado |
| created_at | TIMESTAMP | Fecha y hora del pago |

### Tabla: comprobantes

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| pago_id | INTEGER | FK a pagos (único) |
| numero | VARCHAR(20) | Número de comprobante |
| created_at | TIMESTAMP | Fecha de creación |

### Tabla: pago_tratamientos

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| pago_id | INTEGER | FK a pagos |
| tratamiento_id | INTEGER | FK a tratamientos |
| monto_asignado | DECIMAL(10,2) | Monto asignado a este tratamiento |
| created_at | TIMESTAMP | Fecha de asignación |

### Tabla: sequence_comprobantes

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id | SERIAL | Identificador único |
| ultimo_numero | INTEGER | Último número de comprobante |
| anio | INTEGER | Año de la secuencia |
| updated_at | TIMESTAMP | Última actualización |

---

## API Endpoints

### Autenticación (`/api/auth`)

| Método | Endpoint | Descripción | Auth |
|--------|----------|-------------|------|
| POST | /login | Iniciar sesión | No |
| GET | /me | Obtener usuario actual | Sí |
| GET | /usuarios | Listar usuarios | Admin |
| POST | /usuarios | Crear usuario | Admin |
| PUT | /usuarios/:id | Actualizar usuario | Admin |
| PUT | /usuarios/:id/password | Cambiar contraseña | Sí* |
| GET | /cajeros | Listar cajeros | Sí |

### Pacientes (`/api/pacientes`)

| Método | Endpoint | Descripción | Auth |
|--------|----------|-------------|------|
| GET | / | Listar pacientes | Sí |
| GET | /buscar?q= | Buscar pacientes | Sí |
| GET | /:id | Obtener paciente | Sí |
| GET | /dni/:dni | Buscar por DNI | Sí |
| POST | / | Crear paciente | Sí |
| PUT | /:id | Actualizar paciente | Sí |
| DELETE | /:id | Eliminar paciente | Sí |

### Tratamientos (`/api/tratamientos`)

| Método | Endpoint | Descripción | Auth |
|--------|----------|-------------|------|
| GET | / | Listar tratamientos | Sí |
| GET | /paciente/:id | Tratamientos de paciente | Sí |
| GET | /:id | Obtener tratamiento | Sí |
| GET | /:id/saldo | Obtener saldo | Sí |
| POST | / | Crear tratamiento | Sí |
| PUT | /:id | Actualizar tratamiento | Sí |
| DELETE | /:id | Cancelar tratamiento | Sí |

### Pagos (`/api/pagos`)

| Método | Endpoint | Descripción | Auth |
|--------|----------|-------------|------|
| GET | / | Listar pagos (con filtros) | Sí |
| GET | /stats | Estadísticas | Sí |
| GET | /:id | Obtener pago | Sí |
| POST | / | Registrar pago | Sí |
| PUT | /:id/firma | Actualizar firma | Sí |
| PUT | /:id/anular | Anular pago | Admin |

### Comprobantes (`/api/comprobantes`)

| Método | Endpoint | Descripción | Auth |
|--------|----------|-------------|------|
| GET | / | Listar comprobantes | Sí |
| GET | /:pagoId | Obtener comprobante | Sí |
| GET | /numero/:numero | Buscar por número | Sí |

---

## Fórmulas y Lógica de Negocio

### 1. Cálculo de Saldo de Tratamiento

```typescript
// Fórmula: saldo = monto_total - monto_pagado
const saldo = tratamiento.monto_total - tratamiento.monto_pagado;
```

**Descripción:** El saldo pendiente de un tratamiento se calcula restando el monto ya pagado del monto total del tratamiento.

**Ejemplo:**
- Tratamiento ortodoncia: S/ 5,000
- Pagos realizados: S/ 1,500
- **Saldo pendiente:** S/ 3,500

**Ubicación en código:**
- Backend: `server/src/models/tratamiento.ts` - función `getSaldo()`
- Frontend: `client/src/pages/NuevoPagoPage.tsx` - línea de cálculo

### 2. Actualización Automática de Monto Pagado

```typescript
// Fórmula: monto_pagado = monto_pagado + pago.monto
// Estado se actualiza si: monto_pagado >= monto_total
```

**Descripción:** Cuando se registra un pago vinculado a un tratamiento, el sistema:
1. Suma el monto del pago al `monto_pagado` del tratamiento
2. Verifica si el tratamiento está completamente pagado
3. Si `monto_pagado >= monto_total`, cambia el estado a 'completado'

**Ubicación en código:**
- Backend: `server/src/models/pago.ts` - función `create()`, líneas de UPDATE

### 3. Generación de Número de Comprobante

```typescript
// Fórmula: numero = ultimo_numero + 1
// Se reinicia cada año
```

**Descripción:** El número de comprobante se genera automáticamente:
1. Consulta el último número de la secuencia
2. Incrementa en 1
3. Si cambia el año, reinicia a 1
4. Asocia el número al pago creado

**Ubicación en código:**
- Backend: `server/src/models/pago.ts` - función `create()`, líneas de INSERT en sequence_comprobantes

### 4. Validación de Pago Parcial de Ortodoncia

```typescript
// El pago no puede exceder el saldo pendiente
if (pago.monto > saldoPendiente) {
  throw new Error("El pago excede el saldo pendiente");
}
```

**Descripción:** Al registrar un pago para ortodoncia, se valida que:
1. El pago sea mayor a 0
2. El pago no exceda el saldo pendiente (opcional - actualmente no implementado)

**Ubicación en código:**
- Frontend: `client/src/pages/NuevoPagoPage.tsx` - `handlePagoSubmit()`

### 5. Autenticación JWT

```typescript
// Token contiene: { id, username, rol }
// Expira en: 8 horas (configurable en .env)
```

**Descripción:** El sistema usa JSON Web Tokens para autenticación:
1. Al hacer login, genera un token con los datos del usuario
2. El token expira en 8 horas
3. Cada request debe incluir el token en el header `Authorization: Bearer <token>`
4. El middleware `authenticateToken` valida el token en cada request

**Ubicación en código:**
- Backend: `server/src/middleware/auth.ts` - funciones `generateToken()`, `authenticateToken()`
- Frontend: `client/src/services/api.ts` - interceptor de requests

### 6. Encriptación de Contraseñas

```typescript
// Algoritmo: bcrypt con salt rounds = 10
const hash = await bcrypt.hash(password, 10);
const isValid = await bcrypt.compare(password, hash);
```

**Descripción:** Las contraseñas se almacenan encriptadas usando bcrypt:
1. Al crear usuario, la contraseña se hashea con bcrypt
2. Al hacer login, se compara la contraseña ingresada con el hash almacenado

**Ubicación en código:**
- Backend: `server/src/models/usuario.ts` - funciones `hashPassword()`, `verifyPassword()`

---

## Modelos de Datos

### Modelo: Usuario

```typescript
interface Usuario {
  id: number;
  username: string;
  password_hash: string;
  nombre_completo: string;
  rol: 'admin' | 'cajero';
  activo: boolean;
  created_at: Date;
  updated_at: Date;
}
```

**Roles:**
- `admin`: Acceso total al sistema, puede gestionar usuarios
- `cajero`: Puede registrar pagos y gestionar pacientes

### Modelo: Paciente

```typescript
interface Paciente {
  id: number;
  nombre: string;
  dni: string | null;
  telefono: string | null;
  email: string | null;
  direccion: string | null;
  activo: boolean;
  created_at: Date;
  updated_at: Date;
}
```

**Restricciones:**
- DNI debe ser único (8 dígitos)

### Modelo: Tratamiento

```typescript
interface Tratamiento {
  id: number;
  paciente_id: number;
  tipo: string;
  descripcion: string | null;
  monto_total: number;
  monto_pagado: number;
  fecha_inicio: Date;
  fecha_fin: Date | null;
  estado: 'activo' | 'completado' | 'cancelado';
  created_at: Date;
  updated_at: Date;
}
```

**Tipos de tratamiento:**
- `ortodoncia` - Ortodoncia (pagos en cuotas)
- `endodoncia` - Endodoncia
- `limpieza` - Limpieza dental
- `corona` - Corona dental
- `extraccion` - Extracción
- `blanqueamiento` - Blanqueamiento
- `implante` - Implante dental
- `ortopedia` - Ortopedia
- `resina` - Resina
- `otro` - Otro tratamiento

**Estados:**
- `activo`: Tratamiento en curso, puede recibir pagos
- `completado`: Tratamiento terminado y pagado
- `cancelado`: Tratamiento cancelado

### Modelo: Pago

```typescript
interface Pago {
  id: number;
  paciente_id: number;
  usuario_id: number;
  monto: number;
  metodo_pago: 'efectivo' | 'tarjeta' | 'transferencia' | 'yape' | 'plin';
  concepto: string;
  firma_dataurl: string | null;
  estado: 'pendiente' | 'completado' | 'anulado';
  created_at: Date;
}
```

**Métodos de pago:**
- `efectivo`
- `tarjeta` (débito/crédito)
- `transferencia` (banco)
- `yape`
- `plin`

---

## Flujos de Usuario

### Flujo 1: Registro de Pago con Tratamiento

```
┌─────────────────────────────────────────────────────────────────┐
│                     REGISTRO DE PAGO                             │
└─────────────────────────────────────────────────────────────────┘

1. Cajero inicia sesión
       │
       ▼
2. Ve a "Nuevo Pago"
       │
       ▼
3. Busca/selecciona paciente
       │
       ▼
4. Sistema carga tratamientos activos del paciente
       │
       ▼
5. Cajero selecciona tratamiento (ej: Ortodoncia)
       │
       ▼
6. Sistema muestra:
   - Total: S/ 5,000
   - Pagado: S/ 1,500
   - Pendiente: S/ 3,500
   - Pre-llena monto con saldo pendiente
       │
       ▼
7. Cajero ingresa/ajusta monto, método, concepto
       │
       ▼
8. Paciente firma en tablet/pantalla
       │
       ▼
9. Cajero confirma pago
       │
       ▼
10. Sistema:
    a. Crea registro en tabla pagos
    b. Genera número de comprobante
    c. Crea registro en tabla comprobantes
    d. Si hay tratamiento_id:
       - Actualiza monto_pagado del tratamiento
       - Si monto_pagado >= monto_total → estado = 'completado'
    e. Crea registro en pago_tratamientos
       │
       ▼
11. Muestra comprobante para imprimir
```

### Flujo 2: Creación de Tratamiento

```
┌─────────────────────────────────────────────────────────────────┐
│                   CREACIÓN DE TRATAMIENTO                        │
└─────────────────────────────────────────────────────────────────┘

1. Admin/Cajero va a "Tratamientos"
       │
       ▼
2. Clic en "Nuevo Tratamiento"
       │
       ▼
3. Selecciona paciente
       │
       ▼
4. Ingresa:
   - Tipo: Ortodoncia
   - Monto Total: S/ 5,000
   - Fecha Inicio: 01/04/2026
   - Descripción: Brackets metálicos
       │
       ▼
5. Confirma creación
       │
       ▼
6. Sistema crea tratamiento con:
   - monto_pagado: 0
   - estado: activo
       │
       ▼
7. Tratamiento aparece en lista
```

---

## Configuración

### Variables de Entorno (Server)

```env
# Servidor
PORT=3001                    # Puerto del servidor
NODE_ENV=development         # Entorno (development/production)

# Base de datos
DB_HOST=localhost           # Host de PostgreSQL
DB_PORT=5432               # Puerto de PostgreSQL
DB_NAME=ventura_dental     # Nombre de la base de datos
DB_USER=postgres           # Usuario de PostgreSQL
DB_PASSWORD=               # Contraseña (vacío para Postgres.app)

# Autenticación
JWT_SECRET=tu-secret-key    # Clave secreta para JWT
JWT_EXPIRES_IN=8h          # Tiempo de expiración del token

# Negocio
BUSINESS_NAME=Ventura Dental
BUSINESS_RUC=20XXXXXXXXX
BUSINESS_ADDRESS=Por definir
BUSINESS_PHONE=
```

### Variables de Entorno (Client)

No requiere archivo `.env`. La configuración del proxy está en `vite.config.ts`:

```typescript
server: {
  port: 5173,
  proxy: {
    '/api': {
      target: 'http://localhost:3001',
      changeOrigin: true,
    },
  },
}
```

---

## Deploy

### Desarrollo Local

```bash
# 1. Instalar dependencias del servidor
cd server
npm install

# 2. Crear base de datos en PostgreSQL
# Usar Postgres.app o pgAdmin

# 3. Iniciar servidor
npm run dev

# 4. En otra terminal, instalar dependencias del cliente
cd client
npm install

# 5. Iniciar cliente
npm run dev

# 6. Abrir navegador en http://localhost:5173
```

### Producción (Básico)

```bash
# Build del cliente
cd client
npm run build

# El build se genera en client/dist/

# Servir archivos estáticos con Express o nginx
```

---

## Troubleshooting

### Error: "Connection terminated unexpectedly"

**Causa:** PostgreSQL no está corriendo o la conexión timeout.

**Solución:**
1. Verificar que Postgres.app esté corriendo
2. Verificar credenciales en `.env`
3. Probar conexión: `psql -h localhost -U postgres -d ventura_dental`

### Error: "Token inválido o expirado"

**Causa:** El token JWT expiró o es inválido.

**Solución:**
1. Cerrar sesión y volver a iniciar
2. Verificar que la hora del sistema sea correcta

### Error: "Tabla no existe"

**Causa:** La base de datos no está inicializada.

**Solución:**
1. Ejecutar `npm run db:init` en el servidor
2. O reiniciar el servidor (inicializa automáticamente)

---

## Contacto y Soporte

Para soporte técnico o reporte de bugs, contactar al equipo de desarrollo.

**Documentación adicional:**
- `docs/API.md` - Documentación detallada de endpoints
- `docs/ARQUITECTURA.md` - Diagramas de arquitectura
- `README.md` - Guía de inicio rápido
