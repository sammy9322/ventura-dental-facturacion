# Documentación de API
## Sistema de Facturación - Ventura Dental

**Base URL:** `http://localhost:3001/api`  
**Formato:** JSON  
**Autenticación:** Bearer Token (JWT)

---

## Headers Requeridos

Para todas las rutas excepto `/auth/login`:

```
Authorization: Bearer <token_jwt>
Content-Type: application/json
```

---

## Autenticación

### POST /auth/login

Iniciar sesión en el sistema.

**Request:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Response (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "admin",
    "nombre_completo": "Administrador",
    "rol": "admin"
  }
}
```

**Errores:**
- `401`: Usuario o contraseña incorrectos

---

### GET /auth/me

Obtener información del usuario actual.

**Response (200):**
```json
{
  "id": 1,
  "username": "admin",
  "nombre_completo": "Administrador",
  "rol": "admin",
  "activo": true,
  "created_at": "2026-04-09T10:00:00.000Z"
}
```

---

### GET /auth/usuarios

Listar todos los usuarios. **Requiere rol admin.**

**Response (200):**
```json
[
  {
    "id": 1,
    "username": "admin",
    "nombre_completo": "Administrador",
    "rol": "admin",
    "activo": true,
    "created_at": "2026-04-09T10:00:00.000Z"
  },
  {
    "id": 2,
    "username": "caja",
    "nombre_completo": "Cajero Principal",
    "rol": "cajero",
    "activo": true,
    "created_at": "2026-04-09T10:00:00.000Z"
  }
]
```

---

### POST /auth/usuarios

Crear un nuevo usuario. **Requiere rol admin.**

**Request:**
```json
{
  "username": "nuevo_caja",
  "password": "password123",
  "nombre_completo": "Juan Pérez",
  "rol": "cajero"
}
```

**Response (201):**
```json
{
  "id": 3,
  "username": "nuevo_caja",
  "nombre_completo": "Juan Pérez",
  "rol": "cajero"
}
```

**Errores:**
- `400`: Datos inválidos o username duplicado

---

### PUT /auth/usuarios/:id

Actualizar un usuario. **Requiere rol admin.**

**Request:**
```json
{
  "nombre_completo": "Juan García",
  "rol": "admin",
  "activo": false
}
```

---

### PUT /auth/usuarios/:id/password

Cambiar contraseña de un usuario.

**Request:**
```json
{
  "newPassword": "nueva_contraseña"
}
```

---

## Pacientes

### GET /pacientes

Listar todos los pacientes.

**Query Parameters:**
- `activo` (boolean): Filtrar por estado activo

**Response (200):**
```json
[
  {
    "id": 1,
    "nombre": "María López",
    "dni": "12345678",
    "telefono": "999888777",
    "email": "maria@email.com",
    "direccion": "Av. Lima 123",
    "activo": true,
    "created_at": "2026-04-09T10:00:00.000Z",
    "updated_at": "2026-04-09T10:00:00.000Z"
  }
]
```

---

### GET /pacientes/buscar?q=

Buscar pacientes por nombre, DNI o teléfono.

**Query Parameters:**
- `q` (string, requerido): Término de búsqueda (mínimo 1 carácter)

**Response (200):**
```json
[
  {
    "id": 1,
    "nombre": "María López",
    "dni": "12345678",
    "telefono": "999888777",
    "email": "maria@email.com",
    "activo": true
  }
]
```

---

### GET /pacientes/:id

Obtener un paciente por ID.

**Response (200):**
```json
{
  "id": 1,
  "nombre": "María López",
  "dni": "12345678",
  "telefono": "999888777",
  "email": "maria@email.com",
  "direccion": "Av. Lima 123",
  "activo": true,
  "created_at": "2026-04-09T10:00:00.000Z",
  "updated_at": "2026-04-09T10:00:00.000Z"
}
```

---

### GET /pacientes/dni/:dni

Buscar paciente por DNI.

**Response (200):**
```json
{
  "id": 1,
  "nombre": "María López",
  "dni": "12345678"
}
```

**Errores:**
- `404`: Paciente no encontrado

---

### POST /pacientes

Crear un nuevo paciente.

**Request:**
```json
{
  "nombre": "Carlos García",
  "dni": "87654321",
  "telefono": "988777666",
  "email": "carlos@email.com",
  "direccion": "Av. Arequipa 456"
}
```

**Response (201):**
```json
{
  "id": 2,
  "nombre": "Carlos García",
  "dni": "87654321",
  "telefono": "988777666",
  "email": "carlos@email.com",
  "direccion": "Av. Arequipa 456",
  "activo": true,
  "created_at": "2026-04-09T10:00:00.000Z",
  "updated_at": "2026-04-09T10:00:00.000Z"
}
```

---

### PUT /pacientes/:id

Actualizar un paciente.

**Request:**
```json
{
  "nombre": "Carlos José García",
  "telefono": "999000111",
  "email": "carlos.jose@email.com"
}
```

---

### DELETE /pacientes/:id

Desactivar un paciente (soft delete).

**Response (200):**
```json
{
  "message": "Paciente desactivado correctamente"
}
```

---

## Tratamientos

### GET /tratamientos

Listar tratamientos.

**Query Parameters:**
- `pacienteId` (integer): Filtrar por paciente
- `tipo` (string): Filtrar por tipo (ortodoncia, endodoncia, etc.)
- `estado` (string): Filtrar por estado (activo, completado, cancelado)

**Response (200):**
```json
[
  {
    "id": 1,
    "paciente_id": 1,
    "tipo": "ortodoncia",
    "descripcion": "Brackets metálicos",
    "monto_total": 5000.00,
    "monto_pagado": 1500.00,
    "fecha_inicio": "2026-04-01",
    "fecha_fin": null,
    "estado": "activo",
    "paciente_nombre": "María López",
    "paciente_dni": "12345678",
    "created_at": "2026-04-01T10:00:00.000Z",
    "updated_at": "2026-04-09T10:00:00.000Z"
  }
]
```

---

### GET /tratamientos/paciente/:pacienteId

Obtener tratamientos de un paciente específico.

**Response (200):**
```json
[
  {
    "id": 1,
    "paciente_id": 1,
    "tipo": "ortodoncia",
    "descripcion": "Brackets metálicos",
    "monto_total": 5000.00,
    "monto_pagado": 1500.00,
    "fecha_inicio": "2026-04-01",
    "estado": "activo"
  }
]
```

---

### GET /tratamientos/:id

Obtener un tratamiento por ID.

---

### GET /tratamientos/:id/saldo

Obtener el saldo de un tratamiento.

**Response (200):**
```json
{
  "monto_total": 5000.00,
  "monto_pagado": 1500.00,
  "saldo": 3500.00
}
```

---

### POST /tratamientos

Crear un nuevo tratamiento.

**Request:**
```json
{
  "paciente_id": 1,
  "tipo": "ortodoncia",
  "descripcion": "Brackets metálicos",
  "monto_total": 5000.00,
  "fecha_inicio": "2026-04-01",
  "fecha_fin": null
}
```

**Response (201):**
```json
{
  "id": 1,
  "paciente_id": 1,
  "tipo": "ortodoncia",
  "descripcion": "Brackets metálicos",
  "monto_total": 5000.00,
  "monto_pagado": 0,
  "fecha_inicio": "2026-04-01",
  "fecha_fin": null,
  "estado": "activo",
  "created_at": "2026-04-01T10:00:00.000Z",
  "updated_at": "2026-04-01T10:00:00.000Z"
}
```

---

### PUT /tratamientos/:id

Actualizar un tratamiento.

**Request:**
```json
{
  "descripcion": "Brackets cerámicos",
  "monto_total": 6000.00,
  "fecha_fin": "2027-04-01",
  "estado": "completado"
}
```

---

### DELETE /tratamientos/:id

Cancelar un tratamiento (soft delete).

**Response (200):**
```json
{
  "message": "Tratamiento cancelado correctamente"
}
```

---

## Pagos

### GET /pagos

Listar pagos con filtros.

**Query Parameters:**
- `fechaDesde` (string, formato YYYY-MM-DD): Filtrar desde fecha
- `fechaHasta` (string, formato YYYY-MM-DD): Filtrar hasta fecha
- `pacienteId` (integer): Filtrar por paciente
- `estado` (string): Filtrar por estado

**Response (200):**
```json
[
  {
    "id": 1,
    "paciente_id": 1,
    "usuario_id": 1,
    "monto": 500.00,
    "metodo_pago": "efectivo",
    "concepto": "Pago parcial - Ortodoncia",
    "firma_dataurl": "data:image/png;base64,...",
    "estado": "completado",
    "created_at": "2026-04-09T10:00:00.000Z",
    "paciente_nombre": "María López",
    "paciente_dni": "12345678",
    "usuario_nombre": "Cajero Principal"
  }
]
```

---

### GET /pagos/stats

Obtener estadísticas de pagos.

**Query Parameters:**
- `fechaDesde` (string): Filtrar desde fecha
- `fechaHasta` (string): Filtrar hasta fecha

**Response (200):**
```json
{
  "total_pagos": "150",
  "monto_total": "45000.00",
  "monto_promedio": "300.00",
  "por_metodo": [
    {
      "metodo_pago": "efectivo",
      "cantidad": "80",
      "total": "25000.00"
    },
    {
      "metodo_pago": "yape",
      "cantidad": "50",
      "total": "15000.00"
    }
  ]
}
```

---

### GET /pagos/:id

Obtener un pago por ID.

---

### POST /pagos

Registrar un nuevo pago.

**Request:**
```json
{
  "paciente_id": 1,
  "monto": 500.00,
  "metodo_pago": "efectivo",
  "concepto": "Pago parcial - Ortodoncia",
  "firma_dataurl": "data:image/png;base64,...",
  "tratamiento_id": 1
}
```

**Response (201):**
```json
{
  "id": 1,
  "paciente_id": 1,
  "usuario_id": 1,
  "monto": 500.00,
  "metodo_pago": "efectivo",
  "concepto": "Pago parcial - Ortodoncia",
  "firma_dataurl": "data:image/png;base64,...",
  "estado": "completado",
  "created_at": "2026-04-09T10:00:00.000Z",
  "comprobante": {
    "id": 1,
    "pago_id": 1,
    "numero": "1",
    "created_at": "2026-04-09T10:00:00.000Z"
  },
  "tratamiento": {
    "id": 1,
    "monto_pagado": 2000.00,
    "estado": "activo"
  }
}
```

**Efectos secundarios:**
- Si `tratamiento_id` está presente:
  - Se actualiza `monto_pagado` del tratamiento
  - Si `monto_pagado >= monto_total`, el estado cambia a 'completado'
  - Se crea registro en `pago_tratamientos`

---

### PUT /pagos/:id/firma

Actualizar la firma de un pago.

**Request:**
```json
{
  "firma_dataurl": "data:image/png;base64,..."
}
```

---

### PUT /pagos/:id/anular

Anular un pago. **Requiere rol admin.**

**Response (200):**
```json
{
  "id": 1,
  "estado": "anulado"
}
```

---

## Comprobantes

### GET /comprobantes/:pagoId

Obtener comprobante de un pago.

**Response (200):**
```json
{
  "id": 1,
  "pago_id": 1,
  "numero": "000001",
  "monto": 500.00,
  "metodo_pago": "efectivo",
  "concepto": "Pago parcial - Ortodoncia",
  "pago_fecha": "2026-04-09T10:00:00.000Z",
  "paciente_nombre": "María López",
  "paciente_dni": "12345678",
  "paciente_telefono": "999888777",
  "paciente_email": "maria@email.com",
  "paciente_direccion": "Av. Lima 123",
  "usuario_nombre": "Cajero Principal",
  "negocio": {
    "nombre": "Ventura Dental",
    "ruc": "20XXXXXXXXX",
    "direccion": "Por definir",
    "telefono": ""
  }
}
```

---

### GET /comprobantes/numero/:numero

Buscar comprobante por número.

---

## Códigos de Error

| Código | Descripción |
|--------|-------------|
| 400 | Bad Request - Datos inválidos |
| 401 | Unauthorized - No autenticado |
| 403 | Forbidden - Sin permisos |
| 404 | Not Found - Recurso no encontrado |
| 500 | Internal Server Error - Error del servidor |

**Formato de errores:**
```json
{
  "error": "Mensaje de error",
  "details": "Detalles adicionales (opcional)"
}
```
