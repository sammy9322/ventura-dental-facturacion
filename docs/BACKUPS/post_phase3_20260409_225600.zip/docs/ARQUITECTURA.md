# Ventura Dental - Sistema de Pagos y Comprobantes

## Estructura del Proyecto

```
ventura-dental-facturacion/
├── server/          # Backend (Node.js + Express)
│   ├── src/
│   │   ├── config/       # Configuración
│   │   ├── controllers/  # Controladores
│   │   ├── middleware/   # Middleware (auth, errors)
│   │   ├── models/       # Modelos de datos
│   │   ├── routes/       # Rutas API
│   │   ├── scripts/      # Scripts de初始化
│   │   └── index.ts      # Entry point
│   ├── package.json
│   └── tsconfig.json
│
├── client/         # Frontend (React + Vite)
│   ├── src/
│   │   ├── components/    # Componentes reutilizables
│   │   ├── pages/        # Páginas
│   │   ├── services/     # Servicios API
│   │   ├── hooks/        # Hooks personalizados
│   │   ├── types/         # Tipos TypeScript
│   │   ├── styles/        # Estilos CSS
│   │   └── App.tsx        # App principal
│   ├── package.json
│   └── vite.config.ts
│
└── docs/           # Documentación adicional
```

## Setup Rápido

1. **PostgreSQL**: Crear base de datos `ventura_dental`
2. **Backend**: `cd server && npm install && npm run dev`
3. **Frontend**: `cd client && npm install && npm run dev`

## Credenciales

- Admin: admin / admin123
- Cajero: caja / caja123
