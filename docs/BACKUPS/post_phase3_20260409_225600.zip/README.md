# Ventura Dental - Sistema de Facturación Clínica

Sistema de gestión de pagos y comprobantes para consultorios dentales.

## Características

- ✅ Autenticación con roles (Administrador/Cajero)
- ✅ Gestión de pacientes con datos completos
- ✅ Gestión de tratamientos (ortodoncia, endodoncia, etc.)
- ✅ Pagos en cuotas para tratamientos
- ✅ Firma digital en pantalla
- ✅ Generación de comprobantes imprimibles
- ✅ Dashboard con estadísticas
- ✅ Historial de pagos con filtros

---

## Requisitos

- **Node.js** 18+
- **PostgreSQL** 14+ (usando Postgres.app)
- **npm** o **yarn**

---

## Instalación Rápida

### 1. Instalar PostgreSQL

Descargar e instalar [Postgres.app](https://postgresapp.com) para macOS.

### 2. Crear Base de Datos

```bash
# Usar la terminal integrada de Postgres.app o ejecutar:
/Applications/Postgres.app/Contents/Versions/latest/bin/psql -h localhost -U postgres -c "CREATE DATABASE ventura_dental;"
```

### 3. Instalar y Ejecutar

```bash
# Backend
cd server
npm install
npm run dev

# En otra terminal - Frontend
cd client
npm install
npm run dev
```

### 4. Abrir en Navegador

**http://localhost:5173**

---

## Credenciales de Prueba

| Usuario | Contraseña | Rol |
|---------|------------|-----|
| admin | admin123 | Administrador |
| caja | caja123 | Cajero |

---

## Estructura del Proyecto

```
ventura-dental-facturacion/
├── server/          # Backend API (Node.js + Express)
├── client/          # Frontend (React + Vite)
└── docs/            # Documentación
    ├── MANUAL.md    # Manual del desarrollador
    ├── API.md       # Documentación de API
    └── BACKUPS/     # Script de backup
```

---

## Uso del Sistema

### 1. Registrar un Paciente

1. Ve a **Pacientes**
2. Clic en **+ Nuevo Paciente**
3. Ingresa los datos y guarda

### 2. Crear un Tratamiento

1. Ve a **Tratamientos**
2. Clic en **+ Nuevo Tratamiento**
3. Selecciona el paciente
4. Ingresa tipo (ej: ortodoncia), monto total y fecha de inicio

### 3. Registrar un Pago

1. Ve a **Nuevo Pago**
2. Busca y selecciona el paciente
3. (Opcional) Selecciona un tratamiento - el sistema pre-llenará el monto pendiente
4. Ingresa monto, método de pago y concepto
5. Paciente firma en pantalla
6. Clic en **Registrar Pago**
7. Imprime el comprobante

### 4. Ver Estadísticas

Ve a **Dashboard** para ver:
- Total de pagos
- Monto total cobrado
- Promedio por pago
- Desglose por método de pago

---

## Tipos de Tratamiento

- **ortodoncia** - Pagos en cuotas (descuento automático del saldo)
- **endodoncia** - Tratamiento de conducto
- **limpieza** - Limpieza dental
- **corona** - Corona dental
- **extraccion** - Extracción
- **blanqueamiento** - Blanqueamiento
- **implante** - Implante dental
- **ortopedia** - Ortopedia
- **resina** - Resina
- **otro** - Otro tratamiento

---

## Métodos de Pago

- Efectivo
- Tarjeta (débito/crédito)
- Transferencia bancaria
- Yape
- Plin

---

## Scripts de Backup

Crear un backup del código y base de datos:

```bash
cd docs/BACKUPS
chmod +x backup.sh
./backup.sh all
```

Opciones:
- `./backup.sh code` - Solo código fuente
- `./backup.sh db` - Solo base de datos
- `./backup.sh all` - Código y base de datos

Los backups se guardan en `docs/BACKUPS/`.

---

## Documentación

- [Manual del Desarrollador](docs/MANUAL.md) - Arquitectura, modelos, fórmulas, flujos
- [Documentación de API](docs/API.md) - Endpoints y ejemplos

---

## Tecnologías

### Backend
- Node.js + Express
- TypeScript
- PostgreSQL
- JWT (autenticación)
- bcrypt (contraseñas)
- Zod (validación)

### Frontend
- React 18
- Vite
- TypeScript
- React Router
- React Hook Form
- Axios

---

## Solución de Problemas

### Error de conexión a PostgreSQL

1. Verificar que Postgres.app esté corriendo
2. Verificar que la base de datos `ventura_dental` exista
3. Verificar credenciales en `server/.env`

### Frontend no conecta al backend

1. Verificar que el servidor esté corriendo en puerto 3001
2. Verificar que el cliente esté corriendo en puerto 5173
3. Reiniciar ambos servicios

---

## Licencia

MIT
