export { default as api } from './api';
export { authService } from './authService';
export { pacienteService } from './pacienteService';
export { pagoService } from './pagoService';
export { comprobanteService } from './comprobanteService';
export { tratamientoService } from './tratamientoService';
