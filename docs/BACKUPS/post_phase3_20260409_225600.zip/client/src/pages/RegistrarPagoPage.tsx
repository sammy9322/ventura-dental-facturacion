import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, Trash2, CheckCircle, AlertCircle } from 'lucide-react';
import { pacienteService, tratamientoService } from '../services';
import { authService } from '../services';
import { Layout, PacienteSearch } from '../components';
import type { Paciente, Tratamiento, DetallePagoItem } from '../types';
import { TIPOS_TRATAMIENTO } from '../types';
import api from '../services/api';

export default function RegistrarPagoPage() {
  const navigate = useNavigate();
  const user = authService.getUser();

  const [paciente, setPaciente] = useState<Paciente | null>(null);
  const [tratamientoPrincipal, setTratamientoPrincipal] = useState<Tratamiento | null>(null);
  const [tratamientosPaciente, setTratamientosPaciente] = useState<Tratamiento[]>([]);
  const [concepto, setConcepto] = useState('');
  const [detalles, setDetalles] = useState<DetallePagoItem[]>([
    { descripcion: '', monto: 0, es_cuota_principal: false }
  ]);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (paciente) cargarTratamientos(paciente.id);
  }, [paciente]);

  const cargarTratamientos = async (pacienteId: number) => {
    try {
      const data = await tratamientoService.getAll({ pacienteId, estado: 'activo' });
      setTratamientosPaciente(data);
    } catch { /* */ }
  };

  // ── Manejo de ítems de detalle ───────────────────────────────────
  const agregarItem = () => {
    setDetalles(prev => [...prev, { descripcion: '', monto: 0, es_cuota_principal: false }]);
  };

  const eliminarItem = (idx: number) => {
    setDetalles(prev => prev.filter((_, i) => i !== idx));
  };

  const actualizarItem = (idx: number, field: keyof DetallePagoItem, value: unknown) => {
    setDetalles(prev => prev.map((d, i) => i === idx ? { ...d, [field]: value } : d));
  };

  const marcarComoCuotaPrincipal = (idx: number) => {
    setDetalles(prev => prev.map((d, i) => ({
      ...d,
      es_cuota_principal: i === idx ? !d.es_cuota_principal : false,
    })));
  };

  const totalPago = detalles.reduce((s, d) => s + (Number(d.monto) || 0), 0);

  const saldoActualizado = () => {
    if (!tratamientoPrincipal) return null;
    const cuota = detalles.find(d => d.es_cuota_principal);
    const abono = cuota ? Number(cuota.monto) : 0;
    return tratamientoPrincipal.monto_total - tratamientoPrincipal.monto_pagado - abono;
  };

  // ── Submit ───────────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paciente) return setError('Seleccione un paciente');
    if (detalles.length === 0 || detalles.every(d => !d.descripcion)) return setError('Agregue al menos un ítem');
    if (detalles.some(d => !d.descripcion || Number(d.monto) <= 0)) return setError('Complete todos los ítems correctamente');

    setError('');
    setSubmitting(true);
    try {
      await api.post('/pagos', {
        paciente_id: paciente.id,
        tratamiento_id: tratamientoPrincipal?.id || undefined,
        concepto: concepto || detalles.map(d => d.descripcion).join(', '),
        detalles,
      });
      setSuccess(true);
      setTimeout(() => navigate('/pagos/registrar'), 2500);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Error al registrar el pago');
    } finally {
      setSubmitting(false);
    }
  };

  const formatMoney = (n: number) =>
    new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN' }).format(n);

  if (success) {
    return (
      <Layout>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: '1rem', textAlign: 'center' }}>
          <CheckCircle size={72} style={{ color: 'var(--accent)' }} />
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.75rem' }}>¡Pago Registrado!</h2>
          <p style={{ color: 'var(--text-secondary)' }}>La secretaria recibirá la notificación para cobrar y emitir el comprobante.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="page-header">
        <h1 className="page-title">Registrar Pago</h1>
        <p className="page-subtitle">El pago quedará pendiente hasta que la secretaria lo finalice</p>
      </div>

      {error && <div className="alert alert-error"><AlertCircle size={16} style={{ marginRight: 8 }} />{error}</div>}

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.5rem', alignItems: 'start' }}>

          {/* ── Panel Izquierdo: Paciente ── */}
          <div className="card">
            <div className="card-header" style={{ marginBottom: '1rem' }}>
              <h3 className="card-title">Datos del Paciente</h3>
            </div>

            <PacienteSearch onSelect={(p) => { setPaciente(p); setTratamientoPrincipal(null); }} selectedPaciente={paciente} />

            {paciente && (
              <div style={{ marginTop: '1rem', padding: '1rem', background: 'rgba(59,130,246,0.07)', borderRadius: 'var(--radius)', border: '1px solid rgba(59,130,246,0.2)' }}>
                <p style={{ fontWeight: 700, color: 'white', marginBottom: '4px' }}>{paciente.nombre}</p>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>DNI: {paciente.dni || 'N/A'} | Tel: {paciente.telefono || 'N/A'}</p>
              </div>
            )}

            {/* Tratamiento principal (para desconto de cuota) */}
            {tratamientosPaciente.length > 0 && (
              <div className="form-group" style={{ marginTop: '1.25rem' }}>
                <label className="form-label">Tratamiento Principal (Cuota)</label>
                <select
                  className="form-select"
                  value={tratamientoPrincipal?.id ?? ''}
                  onChange={e => {
                    const t = tratamientosPaciente.find(t => t.id === parseInt(e.target.value));
                    setTratamientoPrincipal(t || null);
                  }}
                >
                  <option value="">— Sin tratamiento principal —</option>
                  {tratamientosPaciente.map(t => (
                    <option key={t.id} value={t.id}>
                      {TIPOS_TRATAMIENTO.find(x => x.value === t.tipo)?.label || t.tipo} — Saldo: {formatMoney(t.monto_total - t.monto_pagado)}
                    </option>
                  ))}
                </select>
                {tratamientoPrincipal && (
                  <div style={{ marginTop: '0.75rem', padding: '0.875rem', background: 'rgba(15,23,42,0.5)', borderRadius: '8px', fontSize: '0.85rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Total del tratamiento:</span>
                      <span style={{ fontWeight: 600 }}>{formatMoney(tratamientoPrincipal.monto_total)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Total abonado:</span>
                      <span style={{ color: 'var(--accent)', fontWeight: 600 }}>{formatMoney(tratamientoPrincipal.monto_pagado)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '4px', borderTop: '1px solid var(--border)' }}>
                      <span style={{ fontWeight: 700 }}>Saldo actual:</span>
                      <span style={{ fontWeight: 700, color: '#ef4444' }}>{formatMoney(tratamientoPrincipal.monto_total - tratamientoPrincipal.monto_pagado)}</span>
                    </div>
                    {saldoActualizado() !== null && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '4px' }}>
                        <span style={{ color: 'var(--text-muted)' }}>Saldo tras este pago:</span>
                        <span style={{ fontWeight: 700, color: saldoActualizado()! > 0 ? '#f59e0b' : 'var(--accent)' }}>
                          {formatMoney(Math.max(0, saldoActualizado()!))}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ── Panel Derecho: Ítems del Pago ── */}
          <div className="card">
            <div className="card-header" style={{ marginBottom: '1rem' }}>
              <h3 className="card-title">Ítems del Pago</h3>
              <button type="button" className="btn btn-outline btn-sm" onClick={agregarItem}>
                <PlusCircle size={15} /> Agregar
              </button>
            </div>

            <div className="form-group">
              <label className="form-label">Concepto General (opcional)</label>
              <input type="text" className="form-input" placeholder="Ej: Consulta de ortodoncia + limpieza"
                value={concepto} onChange={e => setConcepto(e.target.value)} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {detalles.map((det, idx) => (
                <div key={idx} style={{
                  padding: '1rem', border: `1px solid ${det.es_cuota_principal ? 'rgba(59,130,246,0.4)' : 'var(--border)'}`,
                  borderRadius: 'var(--radius)', background: det.es_cuota_principal ? 'rgba(59,130,246,0.05)' : 'rgba(15,23,42,0.3)',
                  position: 'relative'
                }}>
                  {det.es_cuota_principal && (
                    <span style={{ position: 'absolute', top: '-10px', left: '12px', fontSize: '0.65rem', fontWeight: 700, background: 'var(--primary)', color: 'white', padding: '2px 10px', borderRadius: '999px' }}>
                      CUOTA PRINCIPAL
                    </span>
                  )}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: '0.5rem', alignItems: 'start' }}>
                    <div>
                      <input
                        type="text"
                        className="form-input"
                        placeholder="Descripción (ej: Cuota #3 ortodoncia)"
                        value={det.descripcion}
                        onChange={e => actualizarItem(idx, 'descripcion', e.target.value)}
                        style={{ marginBottom: '0.5rem' }}
                      />
                      <input
                        type="number"
                        className="form-input"
                        placeholder="Monto S/"
                        min="0"
                        step="0.01"
                        value={det.monto || ''}
                        onChange={e => actualizarItem(idx, 'monto', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingTop: '0.1rem' }}>
                      {detalles.length > 1 && (
                        <button type="button" onClick={() => eliminarItem(idx)} title="Eliminar"
                          style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '8px', padding: '6px 8px', cursor: 'pointer', color: '#ef4444' }}>
                          <Trash2 size={15} />
                        </button>
                      )}
                      {tratamientoPrincipal && (
                        <button type="button" onClick={() => marcarComoCuotaPrincipal(idx)} title="Marcar como cuota principal"
                          style={{
                            background: det.es_cuota_principal ? 'rgba(59,130,246,0.2)' : 'rgba(255,255,255,0.05)',
                            border: `1px solid ${det.es_cuota_principal ? 'rgba(59,130,246,0.5)' : 'var(--border)'}`,
                            borderRadius: '8px', padding: '6px 8px', cursor: 'pointer', color: det.es_cuota_principal ? 'var(--primary-light)' : 'var(--text-muted)',
                            fontSize: '0.65rem', fontWeight: 700, textAlign: 'center', lineHeight: 1.3
                          }}>
                          {det.es_cuota_principal ? '✓ Cuota' : 'Cuota?'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Total */}
            <div style={{ borderTop: '2px solid var(--border)', paddingTop: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontWeight: 700, color: 'var(--text-secondary)' }}>TOTAL A REGISTRAR</span>
              <span style={{ fontFamily: 'var(--font-heading)', fontSize: '1.75rem', fontWeight: 800, color: 'var(--primary-light)' }}>
                {formatMoney(totalPago)}
              </span>
            </div>

            <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%', marginTop: '1.25rem', justifyContent: 'center' }} disabled={submitting || !paciente}>
              {submitting ? 'Registrando...' : '📋 Registrar Pago (Notificar a Secretaria)'}
            </button>
          </div>
        </div>
      </form>
    </Layout>
  );
}
