export type Rol = 'admin' | 'doctor' | 'secretaria';

export interface Usuario {
  id: number;
  username: string;
  nombre_completo: string;
  rol: Rol;
  activo: boolean;
  created_at: string;
}

export interface Paciente {
  id: number;
  nombre: string;
  dni: string | null;
  telefono: string | null;
  email: string | null;
  direccion: string | null;
  activo: boolean;
  created_at: string;
  updated_at: string;
}

export interface DetallePagoItem {
  id?: number;
  descripcion: string;
  monto: number;
  es_cuota_principal: boolean;
}

export interface Pago {
  id: number;
  paciente_id: number;
  doctor_id: number;
  secretaria_id: number | null;
  tratamiento_id: number | null;
  monto: number;
  metodo_pago: MetodoPago | null;
  concepto: string;
  firma_dataurl: string | null;
  estado: 'pendiente_cobro' | 'completado' | 'anulado';
  created_at: string;
  finalizado_at: string | null;
  // Joins
  paciente_nombre?: string;
  paciente_dni?: string;
  paciente_telefono?: string;
  paciente_email?: string;
  doctor_nombre?: string;
  secretaria_nombre?: string;
  comprobante_numero?: string;
  detalles?: DetallePagoItem[];
  // Tratamiento
  tratamiento_monto_total?: number;
  tratamiento_monto_pagado?: number;
  tratamiento_tipo?: string;
}

export interface Tratamiento {
  id: number;
  paciente_id: number;
  tipo: string;
  descripcion: string | null;
  monto_total: number;
  monto_pagado: number;
  fecha_inicio: string;
  fecha_fin: string | null;
  estado: 'activo' | 'completado' | 'cancelado';
  created_at: string;
  updated_at: string;
  paciente_nombre?: string;
  paciente_dni?: string;
}

export interface Comprobante {
  id: number;
  pago_id: number;
  numero: string;
  created_at: string;
}

export interface LoginResponse {
  token: string;
  user: Usuario;
}

export interface Stats {
  total_pagos: string;
  monto_total: string;
  por_metodo: { metodo_pago: string; cantidad: string; total: string }[];
}

export type MetodoPago = 'efectivo' | 'tarjeta' | 'transferencia' | 'yape' | 'plin';

export const METODOS_PAGO: { value: MetodoPago; label: string; emoji: string }[] = [
  { value: 'efectivo',      label: 'Efectivo',      emoji: '💵' },
  { value: 'tarjeta',       label: 'Tarjeta',       emoji: '💳' },
  { value: 'transferencia', label: 'Transferencia', emoji: '🏦' },
  { value: 'yape',          label: 'Yape',          emoji: '📱' },
  { value: 'plin',          label: 'Plin',          emoji: '📲' },
];

export const TIPOS_TRATAMIENTO: { value: string; label: string }[] = [
  { value: 'ortodoncia',      label: 'Ortodoncia' },
  { value: 'endodoncia',      label: 'Endodoncia' },
  { value: 'limpieza',        label: 'Limpieza Dental' },
  { value: 'corona',          label: 'Corona' },
  { value: 'extraccion',      label: 'Extracción' },
  { value: 'blanqueamiento',  label: 'Blanqueamiento' },
  { value: 'implante',        label: 'Implante' },
  { value: 'ortopedia',       label: 'Ortopedia' },
  { value: 'resina',          label: 'Resina' },
  { value: 'brackets',        label: 'Brackets' },
  { value: 'consulta',        label: 'Consulta' },
  { value: 'radiografia',     label: 'Radiografía' },
  { value: 'otro',            label: 'Otro' },
];
